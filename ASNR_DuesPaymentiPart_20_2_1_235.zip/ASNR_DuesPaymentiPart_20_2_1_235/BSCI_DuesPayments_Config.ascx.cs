﻿
//using System.Collections;
//using System.Collections.Generic;
//using System.Configuration;
//using System.Linq;
//using System.Web;
//using System.Web.UI.WebControls;
//using System.Data;
//using System.Web.Security;
//using System.Web.UI.HtmlControls;
//using System.Web.UI.WebControls.WebParts;


//from ASI template
using System;
using System.Globalization;
using System.Web.UI;
using Asi.Web.UI;


//namespace BSCI.iPart.BSCIDuesPayments

namespace BSCI.iPart.BSCIDuesPayments
{
    public partial class BSCI_BSCIDuesPayments_Config : ContentItemEditBase
    {


        #region Local Variables and Structures

        #endregion



        #region iMIS Speciifc Overrides

        /// <summary>
        /// Name of atom component that this control will bind to.
        /// </summary>
        public override string AtomComponentName
        {
            get
            {
                // TODO: This must match the 'Name of the Content Type' defined on the Content Type in
                // TODO: 'Content Manager->Maintenance->Content types'
                return "BSCI BSCIDuesPayments";
            }
        }

        #endregion


        #region Events and Events Overrides

        /// <summary>
        /// Form Load Override
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            /// THis example using ASI SmartControl - all properties and configuration params for these controls
            /// should be set in the Serializable class in the ConfigureAtomProperty event.
            //RefreshForm();
        }

        /// <summary>
        /// PreRender event - We use it to read all details about VIEWState variables
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPreRender(EventArgs e)
        {
            // We Need to check if we have form controls and if so we have so save then all to special var
            // All UDT settings stored in special class    
            // Call Custom Method to Update UDTs Struct
            if (Page.IsPostBack)
                //UpdateUDTSettingsArray();
                // Now Do refresh
                //Refresh_Preview();
                base.OnPreRender(e);
        }

        #endregion



        #region Local Processing

        /// <summary>
        /// Method to set/populate form controls
        /// </summary>
        private void RefreshForm()
        {

        }


       



        #endregion


    }
}
