﻿using Asi;
using Asi.Business.ContentManagement;
using Asi.Business.ContentManagement.ContentType;
using Asi.iBO;
using Asi.iBO.Commerce;
using Asi.iBO.Financials;

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Configuration;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;



namespace BSCI.iPart.BSCIDuesPayments
{
  
    public class BSCIDuesPayments
    {

        #region Common Declarations

        BSCI_BSCIDuesPayments_iPart _BSCIPartUtils = new BSCI_BSCIDuesPayments_iPart();


        //Moved this to local for isolation
        Asi.iBO.ContentManagement.CWebUser cWebUser = Asi.iBO.ContentManagement.CWebUser.LoginByPrincipal(AppContext.CurrentPrincipal);               
      

        protected const string sqlInsertTrans = "INSERT INTO Trans( TRANS_NUMBER,  LINE_NUMBER,  BATCH_NUM,  OWNER_ORG_CODE,  SOURCE_SYSTEM,  JOURNAL_TYPE,  TRANSACTION_TYPE,  TRANSACTION_DATE,  BT_ID,  ST_ID,  INVOICE_REFERENCE_NUM,  DESCRIPTION,  CUSTOMER_NAME,  CUSTOMER_REFERENCE,  REFERENCE_1,  SOURCE_CODE,  PRODUCT_CODE,  EFFECTIVE_DATE,  PAID_THRU,  MONTHS_PAID,  FISCAL_PERIOD,  DEFERRAL_MONTHS,  AMOUNT, ADJUSTMENT_AMOUNT,  PSEUDO_ACCOUNT,  GL_ACCT_ORG_CODE,  GL_ACCOUNT,  DEFERRED_GL_ACCOUNT,  INVOICE_CHARGES,  INVOICE_CREDITS,  QUANTITY,  UNIT_PRICE,  PAYMENT_TYPE,  CHECK_NUMBER,  CC_NUMBER,  CC_EXPIRE,  CC_AUTHORIZE,  CC_NAME,  TERMS_CODE,  ACTIVITY_SEQN,  POSTED,  PROD_TYPE,  ACTIVITY_TYPE,  ACTION_CODES,  DATE_ENTERED,  ENTERED_BY,  SUB_LINE_NUMBER,  TAXABLE_VALUE,  SOLICITOR_ID,  INVOICE_ADJUSTMENTS, INVOICE_LINE_NUM,  MERGE_CODE,  SALUTATION_CODE,  SENDER_CODE,  IS_MATCH_GIFT,  MATCH_GIFT_TRANS_NUM,  MATCH_ACTIVITY_SEQN,  MEM_TRIB_ID,  RECEIPT_ID,  DO_NOT_RECEIPT,  CC_STATUS,  ENCRYPT_CC_NUMBER,  ENCRYPT_CC_EXPIRE ,FR_ACTIVITY,FR_ACTIVITY_SEQN,MEM_TRIB_NAME_TEXT,CAMPAIGN_CODE,IS_FR_ITEM,ENCRYPT_CSC,ISSUE_DATE,ISSUE_NUMBER,FR_CHECKBOX,GATEWAY_REF ) VALUES ( @TRANS_NUMBER,  @LINE_NUMBER,  @BATCH_NUM,  @OWNER_ORG_CODE,  @SOURCE_SYSTEM,  @JOURNAL_TYPE,  @TRANSACTION_TYPE,  @TRANSACTION_DATE,  @BT_ID,  @ST_ID,  @INVOICE_REFERENCE_NUM,  @DESCRIPTION,  @CUSTOMER_NAME,  @CUSTOMER_REFERENCE,  @REFERENCE_1,  @SOURCE_CODE,  @PRODUCT_CODE,  @EFFECTIVE_DATE,  @PAID_THRU,  @MONTHS_PAID,  @FISCAL_PERIOD,  @DEFERRAL_MONTHS,  @AMOUNT, @ADJUSTMENT_AMOUNT,  @PSEUDO_ACCOUNT,  @GL_ACCT_ORG_CODE,  @GL_ACCOUNT,  @DEFERRED_GL_ACCOUNT,  @INVOICE_CHARGES,  @INVOICE_CREDITS,  @QUANTITY,  @UNIT_PRICE,  @PAYMENT_TYPE,  @CHECK_NUMBER,  @CC_NUMBER,  @CC_EXPIRE,  @CC_AUTHORIZE,  @CC_NAME,  @TERMS_CODE,  @ACTIVITY_SEQN,  @POSTED,  @PROD_TYPE,  @ACTIVITY_TYPE,  @ACTION_CODES,  @DATE_ENTERED,  @ENTERED_BY,  @SUB_LINE_NUMBER,  @TAXABLE_VALUE,  @SOLICITOR_ID,  @INVOICE_ADJUSTMENTS,  @INVOICE_LINE_NUM,  @MERGE_CODE,  @SALUTATION_CODE,  @SENDER_CODE,  @IS_MATCH_GIFT,  @MATCH_GIFT_TRANS_NUM,  @MATCH_ACTIVITY_SEQN,  @MEM_TRIB_ID,  @RECEIPT_ID,  @DO_NOT_RECEIPT,  @CC_STATUS,  @ENCRYPT_CC_NUMBER,  @ENCRYPT_CC_EXPIRE ,@FR_ACTIVITY,@FR_ACTIVITY_SEQN,@MEM_TRIB_NAME_TEXT,@CAMPAIGN_CODE,@IS_FR_ITEM,@ENCRYPT_CSC, @ISSUE_DATE,@ISSUE_NUMBER ,@FR_CHECKBOX,@GATEWAY_REF )";

        protected const string sqlInsertTrans1 = "INSERT INTO Trans( TRANS_NUMBER,  LINE_NUMBER,  BATCH_NUM,  OWNER_ORG_CODE,  SOURCE_SYSTEM,  JOURNAL_TYPE,  TRANSACTION_TYPE,  TRANSACTION_DATE,  BT_ID,  ST_ID,  INVOICE_REFERENCE_NUM,  DESCRIPTION,  CUSTOMER_NAME,  CUSTOMER_REFERENCE,  REFERENCE_1,  SOURCE_CODE,  PRODUCT_CODE,  MONTHS_PAID,  FISCAL_PERIOD,  DEFERRAL_MONTHS,  AMOUNT, ADJUSTMENT_AMOUNT,  PSEUDO_ACCOUNT,  GL_ACCT_ORG_CODE,  GL_ACCOUNT,  DEFERRED_GL_ACCOUNT,  INVOICE_CHARGES,  INVOICE_CREDITS,  QUANTITY,  UNIT_PRICE,  PAYMENT_TYPE,  CHECK_NUMBER,  CC_NUMBER,  CC_EXPIRE,  CC_AUTHORIZE,  CC_NAME,  TERMS_CODE,  ACTIVITY_SEQN,  POSTED,  PROD_TYPE,  ACTIVITY_TYPE,  ACTION_CODES,  DATE_ENTERED,  ENTERED_BY,  SUB_LINE_NUMBER,  TAXABLE_VALUE,  SOLICITOR_ID,  INVOICE_ADJUSTMENTS, INVOICE_LINE_NUM,  MERGE_CODE,  SALUTATION_CODE,  SENDER_CODE,  IS_MATCH_GIFT,  MATCH_GIFT_TRANS_NUM,  MATCH_ACTIVITY_SEQN,  MEM_TRIB_ID,  RECEIPT_ID,  DO_NOT_RECEIPT,  CC_STATUS,  ENCRYPT_CC_NUMBER,  ENCRYPT_CC_EXPIRE ,FR_ACTIVITY,FR_ACTIVITY_SEQN,MEM_TRIB_NAME_TEXT,CAMPAIGN_CODE,IS_FR_ITEM,ENCRYPT_CSC,ISSUE_DATE,ISSUE_NUMBER,FR_CHECKBOX,GATEWAY_REF ) VALUES ( @TRANS_NUMBER,  @LINE_NUMBER,  @BATCH_NUM,  @OWNER_ORG_CODE,  @SOURCE_SYSTEM,  @JOURNAL_TYPE,  @TRANSACTION_TYPE,  @TRANSACTION_DATE,  @BT_ID,  @ST_ID,  @INVOICE_REFERENCE_NUM,  @DESCRIPTION,  @CUSTOMER_NAME,  @CUSTOMER_REFERENCE,  @REFERENCE_1,  @SOURCE_CODE,  @PRODUCT_CODE,  @MONTHS_PAID,  @FISCAL_PERIOD,  @DEFERRAL_MONTHS,  @AMOUNT, @ADJUSTMENT_AMOUNT,  @PSEUDO_ACCOUNT,  @GL_ACCT_ORG_CODE,  @GL_ACCOUNT,  @DEFERRED_GL_ACCOUNT,  @INVOICE_CHARGES,  @INVOICE_CREDITS,  @QUANTITY,  @UNIT_PRICE,  @PAYMENT_TYPE,  @CHECK_NUMBER,  @CC_NUMBER,  @CC_EXPIRE,  @CC_AUTHORIZE,  @CC_NAME,  @TERMS_CODE,  @ACTIVITY_SEQN,  @POSTED,  @PROD_TYPE,  @ACTIVITY_TYPE,  @ACTION_CODES,  @DATE_ENTERED,  @ENTERED_BY,  @SUB_LINE_NUMBER,  @TAXABLE_VALUE,  @SOLICITOR_ID,  @INVOICE_ADJUSTMENTS,  @INVOICE_LINE_NUM,  @MERGE_CODE,  @SALUTATION_CODE,  @SENDER_CODE,  @IS_MATCH_GIFT,  @MATCH_GIFT_TRANS_NUM,  @MATCH_ACTIVITY_SEQN,  @MEM_TRIB_ID,  @RECEIPT_ID,  @DO_NOT_RECEIPT,  @CC_STATUS,  @ENCRYPT_CC_NUMBER,  @ENCRYPT_CC_EXPIRE ,@FR_ACTIVITY,@FR_ACTIVITY_SEQN,@MEM_TRIB_NAME_TEXT,@CAMPAIGN_CODE,@IS_FR_ITEM,@ENCRYPT_CSC, @ISSUE_DATE,@ISSUE_NUMBER ,@FR_CHECKBOX,@GATEWAY_REF )";


        private string strFinanceAccount = string.Empty;



     


        #endregion




        //public String PayDues(String _imisID, String mEntity, String mCashAccountCode, Decimal mAmount, String mTransactionComment1, 
        //    String mTransactionComment2, String mCreditDebitCardHoldersName, String mCreditCardExpiration,
        //    String mCreditCardNumber, String mAddress1, String mCity, String mStateProvince, String mPostalCode,
        //    Asi.iBO.IiMISUser _user, ArrayList _checkBoxes )
        //{
        //    int i = 0;
           
        //    try
        //    {
        //        DateTime dateValue;
        //        dateValue = DateTime.Parse(mCreditCardExpiration);
        //        mCreditCardExpiration = dateValue.ToString("MM/yy");
        //        string strEntityOrgCode = string.Empty;
        //        Asi.iBO.ContactManagement.CContact _CContact = new Asi.iBO.ContactManagement.CContact(_user, _imisID);
        //        Asi.iBO.ContactManagement.CContactUser coImisUser = Asi.iBO.ContactManagement.CContactUser.LoginByWebLogin("manager");
        //        Asi.iBO.Financials.CPayment cpay = new Asi.iBO.Financials.CPayment(coImisUser);
                
                              
        //            cpay.TransactionComment1 = _CContact.FullName + "   " + mTransactionComment1;
        //            cpay.TransactionComment2 = "ID " + _imisID + " Paid  " + mEntity + "_" + System.DateTime.Today.ToString("ddMMyy"); 
        //            cpay.PaymentType = Asi.iBO.Financials.EnumPaymentType.CreditCard;
        //            cpay.CashAccountCode = mCashAccountCode;
        //            cpay.CreditCardExpiration = mCreditCardExpiration;
        //            cpay.CreditDebitCardHoldersName = mCreditDebitCardHoldersName; 
        //            cpay.CreditCardNumber = mCreditCardNumber; 
        //            //cpay.CreditCardSecurityCode = "123";
        //            cpay.Amount = mAmount;
        //            cpay.Validate();


            
        //        Asi.iBO.ContactManagement.CAddressBasic TheContactAddress = new Asi.iBO.ContactManagement.CAddressBasic(coImisUser);
        //            TheContactAddress.Address1 = mAddress1; 
        //            TheContactAddress.City = mCity; 
        //            TheContactAddress.StateProvince = mStateProvince; 
        //            TheContactAddress.PostalCode = mPostalCode; 

        //        Asi.iBO.ContactManagement.CAddressBasic coAddress = TheContactAddress;
         
        //        Asi.iBO.Commerce.PaymentGatewayResponse cPayRes = cpay.ProcessPayment(Asi.iBO.Commerce.TransactionType.Authorization, coAddress);

        //        if (cPayRes.IsSuccess == true)
        //        {
        //           decimal _AmountPaid = 0;
        //           decimal _AmountOwed = 0;
        //           decimal _AmountDue = 0;
        //           decimal _AmountSubtracted = 0;
                  
        //           //lets reuse this collection latter on.
        //           CSubscription[] PreDuessubs = _CContact.Subscriptions;
        //           int transLineNumbers = 0;
        //            //these were purged in the page oniNIT()
        //           foreach (CSubscription subscription in _CContact.Subscriptions)
        //           {       
        //             _AmountOwed = _AmountOwed + subscription.AmountBilled;
        //               //Owes the targeted fee product
        //             if (subscription.DuesProduct.FinancialEntityCode == mEntity)
        //             {
        //                 _AmountDue = _AmountDue + subscription.Balance;
                     
        //                 if (subscription.ProductTypeCode == "DUES")
        //                 {
        //                     transLineNumbers++;
        //                             _AmountPaid = _AmountPaid + subscription.AmountBilled;
        //                             subscription.SourceCode = "WEB";
        //                            //BMW testing to set these for the correct 12/7/2011 
        //                            //this moves the money into the trans.      
        //                             subscription.AmountPaid = subscription.AmountBilled;                                 
        //                             subscription.BilledContactId = _imisID;                                   
        //                             subscription.DuesProduct.SellOnWeb = true;
        //                             subscription.StatusCode = "A";
        //                             subscription.BilledContactId = _imisID;
        //                             if (subscription.BillThruDate == null)
        //                             {
        //                                 subscription.BillThruDate = Convert.ToDateTime("12/31/" + DateTime.Now.AddYears(i).Year.ToString());

        //                             }

        //                             if (subscription.BillBeginDate == null)
        //                             {
        //                                 ;
        //                                 subscription.BillBeginDate = Convert.ToDateTime("01/01/" + DateTime.Now.AddYears(i).Year.ToString());
        //                             }
        //                             //subscription.BillThruDate = Convert.ToDateTime("12/31/" + DateTime.Now.AddYears(i).Year.ToString());
        //                             //subscription.BillBeginDate = Convert.ToDateTime("01/01/" + DateTime.Now.AddYears(i).Year.ToString());
        //                             subscription.Copies = 1;
        //                             subscription.FutureCopies = 1;
        //                             subscription.Validate();
                                   

        //                 }
        //                 if (subscription.ProductTypeCode == "VOL")
        //                 {
        //                     foreach (CheckBox mCheckBox in _checkBoxes)
        //                     {
        //                         if (mCheckBox.Checked == false && mCheckBox.ID == "ckb_" + subscription.ProductCode.ToString())
        //                         {
                                   
        //                             subscription.AmountPaid = 0;
        //                             subscription.DuesProduct.SellOnWeb = true;
        //                             subscription.StatusCode = "A";
        //                             if (subscription.BillThruDate == null)
        //                             {
        //                                 subscription.BillThruDate = Convert.ToDateTime("12/31/" + DateTime.Now.AddYears(i).Year.ToString());

        //                             }

        //                             if (subscription.BillBeginDate == null)
        //                             {
        //                                 ;
        //                                 subscription.BillBeginDate = Convert.ToDateTime("01/01/" + DateTime.Now.AddYears(i).Year.ToString());
        //                             }
                                                                 
        //                             subscription.Validate();

                                     

        //                         }
        //                         if (mCheckBox.Checked == true && mCheckBox.ID == "ckb_" + subscription.ProductCode.ToString())
        //                         {
        //                             transLineNumbers++;

        //                             _AmountPaid = _AmountPaid + subscription.AmountBilled;
        //                             subscription.SourceCode = "iPRT";
        //                             subscription.AmountPaid = subscription.AmountBilled;
        //                             subscription.BilledContactId = _imisID;
        //                             subscription.DuesProduct.SellOnWeb = true;
        //                             subscription.StatusCode = "A";
        //                             subscription.BilledContactId = _imisID;
        //                             if (subscription.BillThruDate == null)
        //                             {
        //                                 subscription.BillThruDate = Convert.ToDateTime("12/31/" + DateTime.Now.AddYears(i).Year.ToString());

        //                             }

        //                             if (subscription.BillBeginDate == null)
        //                             {
        //                                 ;
        //                                 subscription.BillBeginDate = Convert.ToDateTime("01/01/" + DateTime.Now.AddYears(i).Year.ToString());
        //                             }
                                   
        //                             subscription.Copies = 1;
        //                             subscription.FutureCopies = 1;
        //                             subscription.Validate();

        //                         }

        //                     }
        //                 }
        //             }

                                            
        //             if (subscription.DuesProduct.FinancialEntityCode != mEntity) 
        //             {                        
        //                 //BMW trying to capture the correct amount to subtract.
        //                    _AmountSubtracted = _AmountSubtracted + subscription.Balance + subscription.AmountPaid;
        //                    subscription.IsDuesSynced = false;                          
        //                    subscription.Validate();                 
                        

        //              }
                      

                       
        //            }
        //            //assisgn some timely needed variables.

        //           if (cPayRes.IsSuccess == true)
        //           {
        //               foreach (var account in
        //                   iboAdmin.ReferenceData.CashAccounts.Where(
        //                   account => account.CashAccountCode == mEntity))
        //               {
        //                   strFinanceAccount = account.GLCashAccount;
        //               }
        //           }             
                   
        //           //CBatch batch2 = GetBatch(mEntity, mCashAccountCode);

        //           CBatch batch2 = GetBatch(mEntity, mCashAccountCode, strFinanceAccount, true, _user);
                   
        //            cpay.GetCashAccountFinancialEntity(batch2);                   
        //            strEntityOrgCode = cpay.GetCashAccountFinancialEntity(batch2).FinancialEntityCode.ToString();    


        //           DataServer server = new DataServer(cWebUser);
        //           Asi.iBO.Errors.CErrors errors = CSubscription.PayDues(server, _user, _CContact.Subscriptions, ref cpay, batch2);

              
                   
        //           foreach (CSubscription subscriptionA in PreDuessubs)
        //           {
        //               if (subscriptionA.DuesProduct.FinancialEntityCode == mEntity)
        //               {
        //                   _AmountDue = _AmountDue + subscriptionA.Balance;
                          
        //                   if (subscriptionA.ProductTypeCode == "DUES")
        //                   {
        //                       _AmountPaid = _AmountPaid + subscriptionA.AmountBilled;
        //                       subscriptionA.SourceCode = "iPRT";                              
        //                       subscriptionA.AmountPaid = 0;
        //                       subscriptionA.BilledContactId = _imisID;
        //                       subscriptionA.DuesProduct.SellOnWeb = true;
        //                       subscriptionA.StatusCode = "A";
        //                       subscriptionA.BilledContactId = _imisID;
        //                       if (subscriptionA.BillThruDate == null)
        //                       {
        //                           subscriptionA.BillThruDate = Convert.ToDateTime("12/31/" + DateTime.Now.AddYears(i).Year.ToString());

        //                       }

        //                       if (subscriptionA.BillBeginDate == null)
        //                       {
        //                           ;
        //                           subscriptionA.BillBeginDate = Convert.ToDateTime("01/01/" + DateTime.Now.AddYears(i).Year.ToString());
        //                       }                            
        //                       subscriptionA.Copies = 1;
        //                       subscriptionA.FutureCopies = 1;
        //                       subscriptionA.Validate();                           
        //                    }
        //                   if (subscriptionA.ProductTypeCode == "VOL")
        //                   {
        //                       foreach (CheckBox mCheckBox in _checkBoxes)
        //                       {
                                   
        //                           if (mCheckBox.Checked == true && mCheckBox.ID == "ckb_" + subscriptionA.ProductCode.ToString())
        //                           {

        //                               _AmountPaid = _AmountPaid + subscriptionA.AmountBilled;
        //                               subscriptionA.SourceCode = "iPRT";
        //                               subscriptionA.AmountPaid = 0;
        //                               subscriptionA.BilledContactId = _imisID;                                      
        //                               //This was true when non-ASNR dues were paid and then caused a caculation problem.
        //                               subscriptionA.DuesProduct.SellOnWeb = true;
        //                               subscriptionA.StatusCode = "A";
        //                               subscriptionA.BilledContactId = _imisID;
        //                               if (subscriptionA.BillThruDate == null)
        //                               {
        //                                   subscriptionA.BillThruDate = Convert.ToDateTime("12/31/" + DateTime.Now.AddYears(i).Year.ToString());

        //                               }

        //                               if (subscriptionA.BillBeginDate == null)
        //                               {
                                           
        //                                   subscriptionA.BillBeginDate = Convert.ToDateTime("01/01/" + DateTime.Now.AddYears(i).Year.ToString());
        //                               }
                                      
        //                               subscriptionA.Copies = 1;
        //                               subscriptionA.FutureCopies = 1;
        //                               subscriptionA.Validate();
                                                                  
                                       

        //                           }

        //                       }
        //                   }
        //               }
                                       
                     
                       
                       
        //           }
                       
                       
            
        //               _CContact.Save();

                 

        //          if (errors.ErrorCount > 0)
        //          {
        //              if (errors.PrimaryErrorMessage.Contains("does not match the amount due of"))
        //              {
        //                  int intFiscalPeriod = Asi.iBO.Utilities.CalculateFiscalPeriod(DateTime.Now.Date);
        //                  int countTransLineNumbersB = transLineNumbers + 1;
        //                  int dd = Asi.iBO.iboAdmin.GetCounter(_user, "Trans", 1);
        //                  int transLineNumbersC = 0;
        //                  decimal amounts = 0;
        //                  foreach (CSubscription subscription in _CContact.Subscriptions)
        //                  {
        //                      string comper = string.Empty;

        //                      if (subscription.DuesProduct.FinancialEntityCode == mEntity && subscription.SourceCode == "iPRT")
        //                      {

        //                          string ENCRYPTCCNUMBER = string.Empty;
        //                          string amount = string.Empty;

        //                          string GATEWAYREF = string.Empty;
        //                          string CHECKNUMBER = string.Empty;
        //                          string CCAUTHORIZE = string.Empty;
        //                          string ENCRYPTCCEXPIRE = string.Empty;
        //                          string ENCRYPTCSC = string.Empty;
        //                          transLineNumbersC++;
        //                          amounts = amounts + subscription.AmountBilled;

        //                          comper = "DIST";
        //                          amount = (subscription.AmountBilled * -1).ToString();

        //                          DataServer serverInsertTrans = new DataServer(_user);

        //                          SqlParameter[] paramInsertTrans = new SqlParameter[73];
        //                          int w = 0;
        //                          paramInsertTrans[0] = new SqlParameter("@TRANS_NUMBER", SqlDbType.Int);
        //                          paramInsertTrans[0].Value = dd;
        //                          paramInsertTrans[1] = new SqlParameter("@LINE_NUMBER", SqlDbType.Int);
        //                          paramInsertTrans[1].Value = transLineNumbersC;
        //                          paramInsertTrans[2] = new SqlParameter("@BATCH_NUM", SqlDbType.VarChar);
        //                          paramInsertTrans[2].Value = batch2.BatchNumber;
        //                          paramInsertTrans[3] = new SqlParameter("@OWNER_ORG_CODE", SqlDbType.VarChar);
        //                          paramInsertTrans[3].Value = strEntityOrgCode;
        //                          paramInsertTrans[4] = new SqlParameter("@SOURCE_SYSTEM", SqlDbType.VarChar);
        //                          paramInsertTrans[4].Value = "DUES";
        //                          paramInsertTrans[5] = new SqlParameter("@JOURNAL_TYPE", SqlDbType.VarChar);
        //                          paramInsertTrans[5].Value = "PAY";
        //                          paramInsertTrans[6] = new SqlParameter("@TRANSACTION_TYPE", SqlDbType.VarChar);
        //                          paramInsertTrans[6].Value = comper;
        //                          paramInsertTrans[7] = new SqlParameter("@TRANSACTION_DATE", SqlDbType.DateTime);
        //                          paramInsertTrans[7].Value = DateTime.Now.Date;
        //                          paramInsertTrans[8] = new SqlParameter("@BT_ID", SqlDbType.VarChar);
        //                          paramInsertTrans[8].Value = _imisID;
        //                          paramInsertTrans[9] = new SqlParameter("@ST_ID", SqlDbType.VarChar);
        //                          paramInsertTrans[9].Value = _imisID;
        //                          paramInsertTrans[10] = new SqlParameter("@INVOICE_REFERENCE_NUM", SqlDbType.Float);
        //                          paramInsertTrans[10].Value = 0;
        //                          paramInsertTrans[11] = new SqlParameter("@DESCRIPTION", SqlDbType.VarChar);
        //                          //paramInsertTrans[11].Value = cpay.TransactionComment1;
        //                          paramInsertTrans[11].Value = subscription.DuesProduct.Description;
        //                          paramInsertTrans[12] = new SqlParameter("@CUSTOMER_NAME", SqlDbType.VarChar);
        //                          paramInsertTrans[12].Value = "";
        //                          paramInsertTrans[13] = new SqlParameter("@CUSTOMER_REFERENCE", SqlDbType.VarChar);
        //                          paramInsertTrans[13].Value = "";

        //                          paramInsertTrans[14] = new SqlParameter("@REFERENCE_1", SqlDbType.VarChar);
        //                          paramInsertTrans[14].Value = "";
        //                          paramInsertTrans[15] = new SqlParameter("@SOURCE_CODE", SqlDbType.VarChar);
        //                          paramInsertTrans[15].Value = "";
        //                          paramInsertTrans[16] = new SqlParameter("@PRODUCT_CODE", SqlDbType.VarChar);
        //                          paramInsertTrans[16].Value = subscription.ProductCode;
        //                          paramInsertTrans[17] = new SqlParameter("@EFFECTIVE_DATE", SqlDbType.DateTime);
        //                          paramInsertTrans[17].Value = Convert.ToDateTime("01/01/" + DateTime.Now.AddYears(i).Year.ToString());
        //                          paramInsertTrans[18] = new SqlParameter("@PAID_THRU", SqlDbType.DateTime);
        //                          paramInsertTrans[18].Value = Convert.ToDateTime("12/31/" + DateTime.Now.AddYears(i).Year.ToString());
        //                          paramInsertTrans[19] = new SqlParameter("@MONTHS_PAID", SqlDbType.Int);
        //                          paramInsertTrans[19].Value = 12;
        //                          paramInsertTrans[20] = new SqlParameter("@FISCAL_PERIOD", SqlDbType.Int);
        //                          paramInsertTrans[20].Value = intFiscalPeriod; // 201112;
        //                          paramInsertTrans[21] = new SqlParameter("@DEFERRAL_MONTHS", SqlDbType.Int);
        //                          paramInsertTrans[21].Value = 0;
        //                          paramInsertTrans[22] = new SqlParameter("@AMOUNT", SqlDbType.VarChar);
        //                          paramInsertTrans[22].Value = amount;
        //                          paramInsertTrans[23] = new SqlParameter("@ADJUSTMENT_AMOUNT", SqlDbType.Money);
        //                          paramInsertTrans[23].Value = 0.0000;
        //                          paramInsertTrans[24] = new SqlParameter("@PSEUDO_ACCOUNT", SqlDbType.VarChar);
        //                          //paramInsertTrans[24].Value = subscription.DuesProduct.OtherDescription;
        //                          paramInsertTrans[24].Value = subscription.DuesProduct.FinancialEntityCode + "-DUES-" + subscription.ProductCode;
        //                          //entity-module-productcode or pay

        //                          paramInsertTrans[25] = new SqlParameter("@GL_ACCT_ORG_CODE", SqlDbType.VarChar);
        //                          paramInsertTrans[25].Value = subscription.DuesProduct.FinancialEntityCode;
        //                          paramInsertTrans[26] = new SqlParameter("@GL_ACCOUNT", SqlDbType.VarChar);
        //                          //paramInsertTrans[26].Value = subscription.DuesProduct.IncomeAccount; //ASHNR
        //                          paramInsertTrans[26].Value = batch2.CashGLAccount;
        //                          paramInsertTrans[27] = new SqlParameter("@DEFERRED_GL_ACCOUNT", SqlDbType.VarChar);
        //                          paramInsertTrans[27].Value = "";
        //                          paramInsertTrans[28] = new SqlParameter("@INVOICE_CHARGES", SqlDbType.Money);
        //                          paramInsertTrans[28].Value = 0.0000;
        //                          paramInsertTrans[29] = new SqlParameter("@INVOICE_CREDITS", SqlDbType.Money);
        //                          paramInsertTrans[29].Value = 0.0000;
        //                          paramInsertTrans[30] = new SqlParameter("@QUANTITY", SqlDbType.Int);
        //                          paramInsertTrans[30].Value = 1;
        //                          paramInsertTrans[31] = new SqlParameter("@UNIT_PRICE", SqlDbType.Money);
        //                          paramInsertTrans[31].Value = 0.0000;

        //                          paramInsertTrans[32] = new SqlParameter("@PAYMENT_TYPE", SqlDbType.VarChar);
        //                          paramInsertTrans[32].Value = "";
        //                          paramInsertTrans[33] = new SqlParameter("@CHECK_NUMBER", SqlDbType.VarChar);
        //                          paramInsertTrans[33].Value = CHECKNUMBER;
        //                          paramInsertTrans[34] = new SqlParameter("@CC_NUMBER", SqlDbType.VarChar);
        //                          paramInsertTrans[34].Value = "";
        //                          paramInsertTrans[35] = new SqlParameter("@CC_EXPIRE", SqlDbType.VarChar);
        //                          paramInsertTrans[35].Value = "";
        //                          paramInsertTrans[36] = new SqlParameter("@CC_AUTHORIZE", SqlDbType.VarChar);
        //                          paramInsertTrans[36].Value = CCAUTHORIZE;
        //                          paramInsertTrans[37] = new SqlParameter("@CC_NAME", SqlDbType.VarChar);
        //                          paramInsertTrans[37].Value = "";
        //                          paramInsertTrans[38] = new SqlParameter("@TERMS_CODE", SqlDbType.VarChar);
        //                          paramInsertTrans[38].Value = "";
        //                          paramInsertTrans[39] = new SqlParameter("@ACTIVITY_SEQN", SqlDbType.Int);
        //                          paramInsertTrans[39].Value = 0;
        //                          paramInsertTrans[40] = new SqlParameter("@POSTED", SqlDbType.TinyInt);
        //                          paramInsertTrans[40].Value = 0;
        //                          paramInsertTrans[41] = new SqlParameter("@PROD_TYPE", SqlDbType.VarChar);
        //                          paramInsertTrans[41].Value = subscription.ProductTypeCode.ToString();
        //                          paramInsertTrans[42] = new SqlParameter("@ACTIVITY_TYPE", SqlDbType.VarChar);

        //                          paramInsertTrans[42].Value = subscription.ProductTypeCode.ToString();
        //                          paramInsertTrans[43] = new SqlParameter("@ACTION_CODES", SqlDbType.VarChar);
        //                          paramInsertTrans[43].Value = "A";

        //                          paramInsertTrans[44] = new SqlParameter("@FR_CHECKBOX", SqlDbType.Bit);
        //                          if (subscription.ProductTypeCode == "VOL")
        //                          { w = 1; }
        //                          paramInsertTrans[44].Value = w;
        //                          w = 0;

        //                          paramInsertTrans[45] = new SqlParameter("@DATE_ENTERED", SqlDbType.DateTime);
        //                          paramInsertTrans[45].Value = DateTime.Now.Date;
        //                          paramInsertTrans[46] = new SqlParameter("@ENTERED_BY", SqlDbType.VarChar);
        //                          paramInsertTrans[46].Value = _imisID;

        //                          //This was moved from the end to fix a missed index value assignment.
        //                          paramInsertTrans[47] = new SqlParameter("@GATEWAY_REF", SqlDbType.VarChar);
        //                          //paramInsertTrans[47].Value = cpay.ReferenceNumber;// nothin logged
        //                          paramInsertTrans[47].Value = GATEWAYREF;

        //                          paramInsertTrans[48] = new SqlParameter("@SUB_LINE_NUMBER", SqlDbType.Int);
        //                          paramInsertTrans[48].Value = 1;

        //                          paramInsertTrans[49] = new SqlParameter("@ISSUE_NUMBER", SqlDbType.VarChar);
        //                          paramInsertTrans[49].Value = "";

        //                          paramInsertTrans[50] = new SqlParameter("@TAXABLE_VALUE", SqlDbType.Money);
        //                          paramInsertTrans[50].Value = 0.0000;


        //                          paramInsertTrans[51] = new SqlParameter("@SOLICITOR_ID", SqlDbType.VarChar);
        //                          paramInsertTrans[51].Value = "";
        //                          paramInsertTrans[52] = new SqlParameter("@INVOICE_ADJUSTMENTS", SqlDbType.Money);
        //                          paramInsertTrans[52].Value = 0.0000;
        //                          paramInsertTrans[53] = new SqlParameter("@INVOICE_LINE_NUM", SqlDbType.Int);
        //                          paramInsertTrans[53].Value = 0;
        //                          paramInsertTrans[54] = new SqlParameter("@MERGE_CODE", SqlDbType.VarChar);
        //                          paramInsertTrans[54].Value = "";
        //                          paramInsertTrans[55] = new SqlParameter("@SALUTATION_CODE", SqlDbType.VarChar);
        //                          paramInsertTrans[55].Value = "";
        //                          paramInsertTrans[56] = new SqlParameter("@SENDER_CODE", SqlDbType.VarChar);
        //                          paramInsertTrans[56].Value = "";
        //                          paramInsertTrans[57] = new SqlParameter("@IS_MATCH_GIFT", SqlDbType.TinyInt);
        //                          paramInsertTrans[57].Value = 0;
        //                          paramInsertTrans[58] = new SqlParameter("@MATCH_GIFT_TRANS_NUM", SqlDbType.Int);
        //                          paramInsertTrans[58].Value = 0;
        //                          paramInsertTrans[59] = new SqlParameter("@MATCH_ACTIVITY_SEQN", SqlDbType.Int);
        //                          paramInsertTrans[59].Value = 0;
        //                          paramInsertTrans[60] = new SqlParameter("@MEM_TRIB_ID", SqlDbType.VarChar);
        //                          paramInsertTrans[60].Value = "";


        //                          paramInsertTrans[61] = new SqlParameter("@RECEIPT_ID", SqlDbType.Int);
        //                          paramInsertTrans[61].Value = 0;
        //                          paramInsertTrans[62] = new SqlParameter("@DO_NOT_RECEIPT", SqlDbType.TinyInt);
        //                          paramInsertTrans[62].Value = 0;
        //                          paramInsertTrans[63] = new SqlParameter("@CC_STATUS", SqlDbType.VarChar);
        //                          paramInsertTrans[63].Value = "";
        //                          paramInsertTrans[64] = new SqlParameter("@ENCRYPT_CC_NUMBER", SqlDbType.VarChar);
        //                          paramInsertTrans[64].Value = ENCRYPTCCNUMBER;
        //                          paramInsertTrans[65] = new SqlParameter("@ENCRYPT_CC_EXPIRE", SqlDbType.VarChar);
        //                          paramInsertTrans[65].Value = ENCRYPTCCEXPIRE;
        //                          paramInsertTrans[66] = new SqlParameter("@FR_ACTIVITY", SqlDbType.VarChar);
        //                          paramInsertTrans[66].Value = "";
        //                          paramInsertTrans[67] = new SqlParameter("@FR_ACTIVITY_SEQN", SqlDbType.Int);
        //                          paramInsertTrans[67].Value = 0;
        //                          paramInsertTrans[68] = new SqlParameter("@MEM_TRIB_NAME_TEXT", SqlDbType.VarChar);
        //                          paramInsertTrans[68].Value = "";
        //                          paramInsertTrans[69] = new SqlParameter("@CAMPAIGN_CODE", SqlDbType.VarChar);
        //                          paramInsertTrans[69].Value = "";
        //                          paramInsertTrans[70] = new SqlParameter("@IS_FR_ITEM", SqlDbType.Bit);
        //                          paramInsertTrans[70].Value = subscription.IsFundRaisingItem;
        //                          paramInsertTrans[71] = new SqlParameter("@ENCRYPT_CSC", SqlDbType.VarChar);
        //                          paramInsertTrans[71].Value = ENCRYPTCSC;
        //                          paramInsertTrans[72] = new SqlParameter("@ISSUE_DATE", SqlDbType.VarChar);
        //                          paramInsertTrans[72].Value = "";

        //                          transLineNumbers--;


        //                          using (IDataReader reader2 = serverInsertTrans.ExecuteReader(CommandType.Text, sqlInsertTrans, paramInsertTrans))
        //                          {
        //                              reader2.Read();


        //                          }

        //                          if (amounts == cpay.Amount)
        //                          {
        //                              transLineNumbersC++;
        //                              comper = "PAY";
        //                              ENCRYPTCCNUMBER = cpay.CreditDebitCardNumberEncrypted;
        //                              //amount = (amounts).ToString();
        //                              GATEWAYREF = cpay.TransactionId;
        //                              CHECKNUMBER = cpay.CashAccountCode;
        //                              //cpay.ReferenceNumber;
        //                              CCAUTHORIZE = cpay.CreditDebitCardAuthorizationCode;
        //                              ENCRYPTCCEXPIRE = cpay.CreditCardExpirationEncrypted;
        //                              ENCRYPTCSC = cpay.CreditCardSecurityCodeEncrypted;
                                    
        //                              DataServer serverInsertTrans1 = new DataServer(_user);                                      

        //                              SqlParameter[] paramInsertTrans1 = new SqlParameter[71];
        //                              int ww = 0;
        //                              paramInsertTrans1[0] = new SqlParameter("@TRANS_NUMBER", SqlDbType.Int);
        //                              paramInsertTrans1[0].Value = dd;
        //                              paramInsertTrans1[1] = new SqlParameter("@LINE_NUMBER", SqlDbType.Int);
        //                              paramInsertTrans1[1].Value = transLineNumbersC;
        //                              paramInsertTrans1[2] = new SqlParameter("@BATCH_NUM", SqlDbType.VarChar);
        //                              paramInsertTrans1[2].Value = batch2.BatchNumber;
        //                              paramInsertTrans1[3] = new SqlParameter("@OWNER_ORG_CODE", SqlDbType.VarChar);
        //                              paramInsertTrans1[3].Value = strEntityOrgCode;
        //                              paramInsertTrans1[4] = new SqlParameter("@SOURCE_SYSTEM", SqlDbType.VarChar);
        //                              paramInsertTrans1[4].Value = "DUES";
        //                              paramInsertTrans1[5] = new SqlParameter("@JOURNAL_TYPE", SqlDbType.VarChar);
        //                              paramInsertTrans1[5].Value = "PAY";
        //                              paramInsertTrans1[6] = new SqlParameter("@TRANSACTION_TYPE", SqlDbType.VarChar);
        //                              paramInsertTrans1[6].Value = comper;
        //                              paramInsertTrans1[7] = new SqlParameter("@TRANSACTION_DATE", SqlDbType.DateTime);
        //                              paramInsertTrans1[7].Value = DateTime.Now.Date;
        //                              paramInsertTrans1[8] = new SqlParameter("@BT_ID", SqlDbType.VarChar);
        //                              paramInsertTrans1[8].Value = _imisID;
        //                              paramInsertTrans1[9] = new SqlParameter("@ST_ID", SqlDbType.VarChar);
        //                              paramInsertTrans1[9].Value = _imisID;
        //                              paramInsertTrans1[10] = new SqlParameter("@INVOICE_REFERENCE_NUM", SqlDbType.Float);
        //                              paramInsertTrans1[10].Value = 0;
        //                              paramInsertTrans1[11] = new SqlParameter("@DESCRIPTION", SqlDbType.VarChar);
        //                              //paramInsertTrans1[11].Value = cpay.TransactionComment1;
        //                              paramInsertTrans1[11].Value = "";
        //                              paramInsertTrans1[12] = new SqlParameter("@CUSTOMER_NAME", SqlDbType.VarChar);
        //                              paramInsertTrans1[12].Value = "";
        //                              paramInsertTrans1[13] = new SqlParameter("@CUSTOMER_REFERENCE", SqlDbType.VarChar);
        //                              paramInsertTrans1[13].Value = "";

        //                              paramInsertTrans1[14] = new SqlParameter("@REFERENCE_1", SqlDbType.VarChar);
        //                              paramInsertTrans1[14].Value = "";
        //                              paramInsertTrans1[15] = new SqlParameter("@SOURCE_CODE", SqlDbType.VarChar);
        //                              paramInsertTrans1[15].Value = "";
        //                              paramInsertTrans1[16] = new SqlParameter("@PRODUCT_CODE", SqlDbType.VarChar);
        //                              paramInsertTrans1[16].Value = "";

        //                              paramInsertTrans1[17] = new SqlParameter("@ENCRYPT_CSC", SqlDbType.VarChar);
        //                              paramInsertTrans1[17].Value = ENCRYPTCSC;
        //                              paramInsertTrans1[18] = new SqlParameter("@ISSUE_DATE", SqlDbType.VarChar);
        //                              paramInsertTrans1[18].Value = "";
        //                              paramInsertTrans1[19] = new SqlParameter("@MONTHS_PAID", SqlDbType.Int);
        //                              paramInsertTrans1[19].Value = 0;
        //                              paramInsertTrans1[20] = new SqlParameter("@FISCAL_PERIOD", SqlDbType.Int);
        //                              paramInsertTrans1[20].Value = intFiscalPeriod; // 201112;
        //                              paramInsertTrans1[21] = new SqlParameter("@DEFERRAL_MONTHS", SqlDbType.Int);
        //                              paramInsertTrans1[21].Value = 0;
        //                              paramInsertTrans1[22] = new SqlParameter("@AMOUNT", SqlDbType.VarChar);
        //                              paramInsertTrans1[22].Value = cpay.Amount.ToString();


        //                              paramInsertTrans1[23] = new SqlParameter("@ADJUSTMENT_AMOUNT", SqlDbType.Money);
        //                              paramInsertTrans1[23].Value = 0.0000;
        //                              paramInsertTrans1[24] = new SqlParameter("@PSEUDO_ACCOUNT", SqlDbType.VarChar);
        //                              paramInsertTrans1[24].Value = subscription.DuesProduct.FinancialEntityCode + "-DUES-PAY";
        //                              //entity-module-productcode or pay

        //                              paramInsertTrans1[25] = new SqlParameter("@GL_ACCT_ORG_CODE", SqlDbType.VarChar);
        //                              paramInsertTrans1[25].Value = subscription.DuesProduct.FinancialEntityCode;
        //                              paramInsertTrans1[26] = new SqlParameter("@GL_ACCOUNT", SqlDbType.VarChar);
        //                              paramInsertTrans1[26].Value = batch2.CashGLAccount;
        //                              paramInsertTrans1[27] = new SqlParameter("@DEFERRED_GL_ACCOUNT", SqlDbType.VarChar);
        //                              paramInsertTrans1[27].Value = "";
        //                              paramInsertTrans1[28] = new SqlParameter("@INVOICE_CHARGES", SqlDbType.Money);
        //                              paramInsertTrans1[28].Value = 0.0000;
        //                              paramInsertTrans1[29] = new SqlParameter("@INVOICE_CREDITS", SqlDbType.Money);
        //                              paramInsertTrans1[29].Value = 0.0000;
        //                              paramInsertTrans1[30] = new SqlParameter("@QUANTITY", SqlDbType.Int);
        //                              paramInsertTrans1[30].Value = 1;
        //                              paramInsertTrans1[31] = new SqlParameter("@UNIT_PRICE", SqlDbType.Money);
        //                              paramInsertTrans1[31].Value = 0.0000;

        //                              paramInsertTrans1[32] = new SqlParameter("@PAYMENT_TYPE", SqlDbType.VarChar);
        //                              paramInsertTrans1[32].Value = "CC";
        //                              paramInsertTrans1[33] = new SqlParameter("@CHECK_NUMBER", SqlDbType.VarChar);
        //                              paramInsertTrans1[33].Value = CHECKNUMBER;
        //                              paramInsertTrans1[34] = new SqlParameter("@CC_NUMBER", SqlDbType.VarChar);
        //                              paramInsertTrans1[34].Value = cpay.CreditDebitCardNumberMasked;
        //                              paramInsertTrans1[35] = new SqlParameter("@CC_EXPIRE", SqlDbType.VarChar);
        //                              paramInsertTrans1[35].Value = cpay.CreditCardExpirationMasked;
        //                              paramInsertTrans1[36] = new SqlParameter("@CC_AUTHORIZE", SqlDbType.VarChar);
        //                              paramInsertTrans1[36].Value = CCAUTHORIZE;
        //                              paramInsertTrans1[37] = new SqlParameter("@CC_NAME", SqlDbType.VarChar);
        //                              paramInsertTrans1[37].Value = _CContact.FullName;
        //                              paramInsertTrans1[38] = new SqlParameter("@TERMS_CODE", SqlDbType.VarChar);
        //                              paramInsertTrans1[38].Value = "";
        //                              paramInsertTrans1[39] = new SqlParameter("@ACTIVITY_SEQN", SqlDbType.Int);
        //                              paramInsertTrans1[39].Value = 0;
        //                              paramInsertTrans1[40] = new SqlParameter("@POSTED", SqlDbType.TinyInt);
        //                              paramInsertTrans1[40].Value = 0;
        //                              paramInsertTrans1[41] = new SqlParameter("@PROD_TYPE", SqlDbType.VarChar);
        //                              paramInsertTrans1[41].Value = "";
        //                              paramInsertTrans1[42] = new SqlParameter("@ACTIVITY_TYPE", SqlDbType.VarChar);

        //                              paramInsertTrans1[42].Value = "";
        //                              paramInsertTrans1[43] = new SqlParameter("@ACTION_CODES", SqlDbType.VarChar);
        //                              paramInsertTrans1[43].Value = "";

        //                              paramInsertTrans1[44] = new SqlParameter("@FR_CHECKBOX", SqlDbType.Bit);
        //                              paramInsertTrans1[44].Value = 0;


        //                              paramInsertTrans1[45] = new SqlParameter("@DATE_ENTERED", SqlDbType.DateTime);
        //                              paramInsertTrans1[45].Value = DateTime.Now.Date;
        //                              paramInsertTrans1[46] = new SqlParameter("@ENTERED_BY", SqlDbType.VarChar);
        //                              paramInsertTrans1[46].Value = _imisID;

        //                              //This was moved from the end to fix a missed index value assignment.
        //                              paramInsertTrans1[47] = new SqlParameter("@GATEWAY_REF", SqlDbType.VarChar);
        //                              paramInsertTrans1[47].Value = GATEWAYREF;

        //                              paramInsertTrans1[48] = new SqlParameter("@SUB_LINE_NUMBER", SqlDbType.Int);
        //                              paramInsertTrans1[48].Value = 1;

        //                              paramInsertTrans1[49] = new SqlParameter("@ISSUE_NUMBER", SqlDbType.VarChar);
        //                              paramInsertTrans1[49].Value = "";

        //                              paramInsertTrans1[50] = new SqlParameter("@TAXABLE_VALUE", SqlDbType.Money);
        //                              paramInsertTrans1[50].Value = 0.0000;


        //                              paramInsertTrans1[51] = new SqlParameter("@SOLICITOR_ID", SqlDbType.VarChar);
        //                              paramInsertTrans1[51].Value = "";
        //                              paramInsertTrans1[52] = new SqlParameter("@INVOICE_ADJUSTMENTS", SqlDbType.Money);
        //                              paramInsertTrans1[52].Value = 0.0000;
        //                              paramInsertTrans1[53] = new SqlParameter("@INVOICE_LINE_NUM", SqlDbType.Int);
        //                              paramInsertTrans1[53].Value = 0;
        //                              paramInsertTrans1[54] = new SqlParameter("@MERGE_CODE", SqlDbType.VarChar);
        //                              paramInsertTrans1[54].Value = "";
        //                              paramInsertTrans1[55] = new SqlParameter("@SALUTATION_CODE", SqlDbType.VarChar);
        //                              paramInsertTrans1[55].Value = "";
        //                              paramInsertTrans1[56] = new SqlParameter("@SENDER_CODE", SqlDbType.VarChar);
        //                              paramInsertTrans1[56].Value = "";
        //                              paramInsertTrans1[57] = new SqlParameter("@IS_MATCH_GIFT", SqlDbType.TinyInt);
        //                              paramInsertTrans1[57].Value = 0;
        //                              paramInsertTrans1[58] = new SqlParameter("@MATCH_GIFT_TRANS_NUM", SqlDbType.Int);
        //                              paramInsertTrans1[58].Value = 0;
        //                              paramInsertTrans1[59] = new SqlParameter("@MATCH_ACTIVITY_SEQN", SqlDbType.Int);
        //                              paramInsertTrans1[59].Value = 0;
        //                              paramInsertTrans1[60] = new SqlParameter("@MEM_TRIB_ID", SqlDbType.VarChar);
        //                              paramInsertTrans1[60].Value = "";


        //                              paramInsertTrans1[61] = new SqlParameter("@RECEIPT_ID", SqlDbType.Int);
        //                              paramInsertTrans1[61].Value = 0;
        //                              paramInsertTrans1[62] = new SqlParameter("@DO_NOT_RECEIPT", SqlDbType.TinyInt);
        //                              paramInsertTrans1[62].Value = 0;
        //                              paramInsertTrans1[63] = new SqlParameter("@CC_STATUS", SqlDbType.VarChar);
        //                              paramInsertTrans1[63].Value = "C";
        //                              paramInsertTrans1[64] = new SqlParameter("@ENCRYPT_CC_NUMBER", SqlDbType.VarChar);
        //                              paramInsertTrans1[64].Value = ENCRYPTCCNUMBER;
        //                              paramInsertTrans1[65] = new SqlParameter("@ENCRYPT_CC_EXPIRE", SqlDbType.VarChar);
        //                              paramInsertTrans1[65].Value = ENCRYPTCCEXPIRE;
        //                              paramInsertTrans1[66] = new SqlParameter("@FR_ACTIVITY", SqlDbType.VarChar);
        //                              paramInsertTrans1[66].Value = "";
        //                              paramInsertTrans1[67] = new SqlParameter("@FR_ACTIVITY_SEQN", SqlDbType.Int);
        //                              paramInsertTrans1[67].Value = 0;
        //                              paramInsertTrans1[68] = new SqlParameter("@MEM_TRIB_NAME_TEXT", SqlDbType.VarChar);
        //                              paramInsertTrans1[68].Value = "";
        //                              paramInsertTrans1[69] = new SqlParameter("@CAMPAIGN_CODE", SqlDbType.VarChar);
        //                              paramInsertTrans1[69].Value = "";
        //                              paramInsertTrans1[70] = new SqlParameter("@IS_FR_ITEM", SqlDbType.Bit);
        //                              paramInsertTrans1[70].Value = 0;

        //                              using (IDataReader reader3 = serverInsertTrans1.ExecuteReader(CommandType.Text, sqlInsertTrans1, paramInsertTrans1))
        //                              {
        //                                  reader3.Read();
        //                              }

        //                          }
        //                      }
        //                  }

        //                  AddTransaction(mAmount, batch2.BatchNumber.ToString());
        //                  return "payDuesSuccess";
        //              }
        //              else
        //              {
                          

        //                  return "payDuesFailure";
        //              }
        //          }

        //            return "payDuesSuccess";

        //        }
        //        else 
        //        {
        //           string cc = cPayRes.ResponseMessage;
        //           return cc;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
               
        //        return "exception";
                
        //    }
           

        //}



        














        //private void AddTransaction(decimal _amount, string _batchNumber)
        //{
        //   DataServer server = new DataServer(cWebUser);            
        //    server.BeginTransaction();               
        //    bool allIsWell = false;
        //    try
        //    {
        //    CBatch batch = new CBatch(cWebUser, _batchNumber);
        //            batch.AddTransaction(server, _amount);
        //            batch.TransCash = _amount;
        //            batch.TransCount = batch.TransCount + 1;
                             

        //        allIsWell = true;
        //    }
        //    catch
        //    {
        //        allIsWell = false;
        //    }
        //    if (allIsWell)
        //            server.CommitTransaction();
        //        else
        //            server.RollbackTransaction();           
            
        //}






        //private CBatch GetBatch(String mEntity, String mCashAccountCode)
        //{            
        //        int iiiii = 0;
        //        iiiii = 1;
        //        var batch = new CBatch(cWebUser);           
        //          //Creates a new batch           
        //        batch = new CBatch(cWebUser);
        //        if (mEntity == "")
        //        {
        //            batch.Description = System.DateTime.Today.ToString("yyMMdd");
        //        }
        //        else
        //        {
        //            batch.Description = mEntity + "_" + System.DateTime.Today.ToString("ddMMyy");
        //        }
        //        batch.DateCreated = DateTime.Now;
        //        batch.CreatedBy = "Internet"; //Changed from Web to meet existing batch format.
        //        batch.CashGLAccount = strFinanceAccount; //mCashGLAccount
        //        batch.EffectiveDate = DateTime.Now;
        //        batch.CashAccountCode = mCashAccountCode; // "GIFTFUND"; //mAccountCode
        //        if (mEntity == "")
        //        {
        //            batch.BatchNumber = System.DateTime.Today.ToString("yyMMdd");
        //        }
        //        else
        //        {
        //            batch.BatchNumber = mEntity + "_" + System.DateTime.Today.ToString("ddMMyy");
        //        }
        //        //Added 11/09/2010
        //        batch.CashEntity = mEntity;

        //        if (batch.Validate())
        //        {
        //            //only if batch is new.
        //            batch.Save();
        //            return batch;
        //        }

        //        //can not validate the batch check on open batches.
        //        if (mEntity == "")
        //        {
        //            //this opens the batch object for modification.
        //            batch = new CBatch(cWebUser, System.DateTime.Today.ToString("yyMMdd") + "-" + iiiii.ToString());
        //        }
        //        else
        //        {
        //            batch = new CBatch(cWebUser, mEntity + "_" + System.DateTime.Today.ToString("ddMMyy"));
        //        }

                
        //        //If Open return this batch
        //        if (batch.PostingStatus == 0)
        //        {
        //            return batch;
        //        }


        //        //If Posted or ready then
        //        else if (batch.PostingStatus > 0 ) //|| batch.PostingStatus = 2)
        //        {
        //            iiiii = 2;
                   
        //            batch = new CBatch(cWebUser);
        //            if (mEntity == "")
        //            {
                        
        //                batch.Description = System.DateTime.Today.ToString("yyMMdd") + "-" + iiiii.ToString();
        //            }
        //            else
        //            {
        //                batch.Description = mEntity + "_" + System.DateTime.Today.ToString("ddMMyy") + "_" + iiiii.ToString();
        //            }
                    
        //            batch.DateCreated = DateTime.Now;
        //            batch.CreatedBy = "Internet";
        //            batch.CashGLAccount = strFinanceAccount; //mCashGLAccount
        //            batch.EffectiveDate = DateTime.Now;
        //            batch.CashAccountCode = mCashAccountCode; // "GIFTFUND"; //mAccountCode
        //            if (mEntity == "")
        //            {
        //                batch.BatchNumber = System.DateTime.Today.ToString("yyMMdd") + iiiii.ToString();
        //            }
        //            else
        //            {
        //                batch.BatchNumber = mEntity + "_" + System.DateTime.Today.ToString("ddMMyy") + "_" + iiiii.ToString();
        //            }
        //            //batch.BatchNumber = mEntity + "_" + System.DateTime.Today.ToString("ddMMyy") + "_1";
        //            //Added 11/09/2010
        //            batch.CashEntity = mEntity;

        //            if (batch.Validate())
        //            {
        //                batch.Save();
        //                return batch;
        //            }

        //            if (mEntity == "")
        //            {
        //                batch = new CBatch(cWebUser, System.DateTime.Today.ToString("yyMMdd") + iiiii.ToString());
        //            }
        //            else
        //            {
        //                batch = new CBatch(cWebUser, mEntity + "_" + System.DateTime.Today.ToString("ddMMyy") + "_" + iiiii.ToString());
        //            }
                    
        //            return batch;
        //        }
        //            return batch;

        //    }



    //     private CBatch GetBatch(String mEntity, String mCashAccountCode, Guid OriginalBatch)
    //    {       

    //            var batch = new CBatch(cWebUser);           
    //              //Creates a new batch           
    //            batch = new CBatch(cWebUser);
    //            batch.Description = mEntity + "_" + System.DateTime.Today.ToString("ddMMyy");
    //            batch.DateCreated = DateTime.Now;
    //            batch.CreatedBy = "Internet"; //Changed from Web to meet existing batch format.
    //            batch.CashGLAccount = "0001130"; //mCashGLAccount
    //            batch.EffectiveDate = DateTime.Now;
    //            batch.CashAccountCode = mCashAccountCode; // "GIFTFUND"; //mAccountCode
    //            batch.BatchNumber = mEntity + "_" + System.DateTime.Today.ToString("ddMMyy");
    //            //Added 11/09/2010
    //            batch.CashEntity = mEntity;

    //            if (batch.Validate())
    //            {
    //                batch.Save();
    //                return batch;
    //            }

    //            //can not validate the batch check on open batches.
    //            batch = new CBatch(cWebUser, mEntity + "_" + System.DateTime.Today.ToString("ddMMyy"));
    //            //If Open return this batch
    //            if (batch.PostingStatus == 0)
    //            {
    //                return batch;
    //            }
    //            //If Posted or ready then
    //            else if (batch.PostingStatus > 0 ) //|| batch.PostingStatus = 2)
    //            {
    //                batch = new CBatch(cWebUser);
    //                batch.Description = mEntity + "_" + System.DateTime.Today.ToString("ddMMyy") + "_1";
    //                batch.DateCreated = DateTime.Now;
    //                batch.CreatedBy = "Internet";
    //                batch.CashGLAccount = "0001130"; //mCashGLAccount
    //                batch.EffectiveDate = DateTime.Now;
    //                batch.CashAccountCode = mCashAccountCode; // "GIFTFUND"; //mAccountCode
    //                batch.BatchNumber = mEntity + "_" + System.DateTime.Today.ToString("ddMMyy") + "_1";
    //                //Added 11/09/2010
    //                batch.CashEntity = mEntity;

    //                if (batch.Validate())
    //                {
    //                    batch.Save();
    //                    return batch;
    //                }
    //                batch = new CBatch(cWebUser, mEntity + "_" + System.DateTime.Today.ToString("ddMMyy") + "_1");
    //                return batch;
    //            }
    //                return batch;

    //        }




        private CBatch GetBatch(String mEntity, String mCashAccountCode, String mFinanceAccount, Boolean somebool, Asi.iBO.IiMISUser imisuser)
        {
            Asi.Security.SecurityContext.LogonByUserId("Manager");
            Asi.iBO.ContentManagement.CWebUser cBatchWebUser = Asi.iBO.ContentManagement.CWebUser.LoginByPrincipal(Asi.AppContext.CurrentPrincipal);
            int iBatchCountOpen = CBatch.GetBatches(imisuser, BatchPostingStatus.Open, System.DateTime.Today).Count();//this has a count
            int iBatchCountPosted = CBatch.GetBatches(imisuser, BatchPostingStatus.Posted, System.DateTime.Today).Count();//this has a count
            int iBatchCountReady = CBatch.GetBatches(imisuser, BatchPostingStatus.Ready, System.DateTime.Today).Count();//this has a count
            int iBatchCountTotal = iBatchCountOpen + iBatchCountPosted + iBatchCountReady;
            CBatch batch2 = new CBatch(cBatchWebUser);
            //batch2 = new CBatch(cBatchWebUser, mEntity + "_" + System.DateTime.Today.ToString("yyMMdd") + "-" + iBatchCountTotal.ToString());                      
            //batch2.BatchNumber == ""
            //"" means operator asssigned
            //These are for internet transactions where a new batch is needed.           
            //A new transaction.

            if (batch2.BatchNumber == "")
            {
                //no batches today.
                if (iBatchCountOpen == 0 && iBatchCountPosted == 0 && iBatchCountReady == 0)
                {
                    iBatchCountOpen++;
                    //if (mEntity == "" && batch2.BatchNumber != "")
                    if (mEntity == "")
                    {
                        batch2.BatchNumber = System.DateTime.Today.ToString("yyMMdd") + "-" + iBatchCountOpen.ToString();

                    }
                    if (mEntity != "")
                    {

                        batch2.BatchNumber = mEntity + "_" + System.DateTime.Today.ToString("yyMMdd") + "-" + iBatchCountOpen.ToString();
                    }
                    if (mEntity == "" && batch2.BatchNumber != "")
                    {

                    }

                }
                else //there are todays batches
                {
                    if (mEntity == "")
                    {
                        batch2.BatchNumber = System.DateTime.Today.ToString("yyMMdd") + "-" + iBatchCountTotal.ToString();

                    }
                    if (mEntity != "")
                    {

                        batch2.BatchNumber = mEntity + "_" + System.DateTime.Today.ToString("yyMMdd") + "-" + iBatchCountTotal.ToString();


                    }
                    if (mEntity == "")
                    {
                        batch2.BatchNumber = System.DateTime.Today.ToString("yyMMdd") + "-" + iBatchCountTotal.ToString();

                    }
                }
                if (batch2.PostingStatus == BatchPostingStatus.Open)
                {
                    if (batch2.Validate())
                    {
                        batch2.Save();
                        return batch2;
                    }
                }


            }

            if (batch2.BatchNumber != "")
            {
                if (iBatchCountTotal == 0)
                {
                    if (batch2.Validate())
                    {
                        batch2.Save();
                        return batch2;
                    }
                }

                if (iBatchCountTotal > 0)
                {
                    //This is correct because it should open the existing batch.
                    if (iBatchCountOpen == 0)
                    {
                        // This means that we use the new batch 
                        // iBatchCountTotal++;
                        // batch2.BatchNumber = System.DateTime.Today.ToString("yyMMdd") + "-" + iBatchCountTotal.ToString();
                        // batch2 = new CBatch(cBatchWebUser, System.DateTime.Today.ToString("yyMMdd") + "-" + iBatchCountTotal.ToString());
                    }
                    if (iBatchCountOpen > 0)
                    {
                        //Else we need to use an existing batch that is already open.
                        //batch2.BatchNumber = System.DateTime.Today.ToString("yyMMdd") + "-" + iBatchCountTotal.ToString();
                        batch2 = new CBatch(cBatchWebUser, System.DateTime.Today.ToString("yyMMdd") + "-" + iBatchCountTotal.ToString());
                    }

                    try
                    {
                        if (batch2.PostingStatus == BatchPostingStatus.Open)
                        {
                            if (batch2.Validate())
                            {
                                batch2.Save();
                                return batch2;
                            }
                        }
                    }
                    catch
                    {
                        if (batch2.Validate())
                        {
                            batch2.Save();
                            return batch2;
                        }
                    }
                }

            }



            //lets get the last open batch of everything except auto sequential.
            //

            try
            {
                batch2 = new CBatch(cBatchWebUser);
                if (iBatchCountOpen > 0 && iBatchCountPosted > 0 && mEntity == "")
                {
                    if (iBatchCountOpen > 0)
                    {
                        //This is correct because it should open the existing batch.
                        iBatchCountOpen = iBatchCountOpen + iBatchCountPosted;
                        batch2 = new CBatch(cBatchWebUser, System.DateTime.Today.ToString("yyMMdd") + "-" + iBatchCountOpen.ToString());
                        if (batch2.PostingStatus == BatchPostingStatus.Open)
                        {
                            if (batch2.Validate())
                            {
                                batch2.Save();
                                return batch2;
                            }
                        }
                    }
                    else
                    {
                        iBatchCountPosted++;
                        batch2.BatchNumber = System.DateTime.Today.ToString("yyMMdd") + "-" + iBatchCountPosted.ToString();
                        batch2.Save();
                        return batch2;


                    }
                }




                else if (batch2.ErrorsCount > 0)
                {
                    CBatch batch3 = new CBatch(cBatchWebUser);
                    if (mEntity != "")
                    {
                        iBatchCountOpen++;
                        if (batch3.BatchNumber != "")
                        {
                            batch3.BatchNumber = System.DateTime.Today.ToString("yyMMdd") + "-" + iBatchCountOpen.ToString();
                        }
                        else
                        {
                            batch3.BatchNumber = mEntity + "_" + System.DateTime.Today.ToString("yyMMdd") + "-" + iBatchCountOpen.ToString();
                        }
                        batch3.CashEntity = mEntity;


                    }

                    if (batch3.Validate())
                    {

                        batch3.Save();
                        return batch2;
                    }

                }
            }
            catch
            {
                batch2.Save();
                return batch2;
            }
            finally
            { }

            batch2.Save();
            return batch2;

        }


    }




        
     
	}

