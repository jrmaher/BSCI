
-- 

--  ..







DROP VIEW vBSCI_TotalUserFees
GO

CREATE VIEW vBSCI_TotalUserFees
AS


select Name.ID, sum(BALANCE) AS TOTAL_FEE_BALANCE 
FROM Name LEFT OUTER JOIN Subscriptions ON Name.ID = Subscriptions.ID
WHERE Name.ID NOT IN (SELECT ID FROM vBSCI_TotalUserFees_PendingSitePayments)
GROUP BY Name.ID 

union

-- PAID ON SITE BUT BATCH ISN'T POSTED ..
select ID, TOTAL_FEE_BALANCE 
FROM vBSCI_TotalUserFees_PendingSitePayments
--GROUP BY ID 

GO

GRANT SELECT ON vBSCI_TotalUserFees TO IMIS
GO




select * from vBSCI_TotalUserFees where ID = '3121898'

