





DROP VIEW vBSCI_TotalUserFees_PendingSitePayments
GO

CREATE VIEW vBSCI_TotalUserFees_PendingSitePayments
AS


select vBSCI_TotalUserFees_PendingSitePayments_FeeBase.ID, 0 AS TOTAL_FEE_BALANCE
FROM vBSCI_TotalUserFees_PendingSitePayments_FeeBase, vBSCI_TotalUserFees_PendingSitePayments_TransBase
where vBSCI_TotalUserFees_PendingSitePayments_TransBase.ST_ID = vBSCI_TotalUserFees_PendingSitePayments_FeeBase.ID
AND vBSCI_TotalUserFees_PendingSitePayments_TransBase.AMOUNT = vBSCI_TotalUserFees_PendingSitePayments_FeeBase.SumOfBALANCE
GO



GRANT SELECT ON vBSCI_TotalUserFees_PendingSitePayments TO IMIS
GO



--select * from vARDC_TotalIndAttyFees_ExcludeSitePayments where ID = '6199252'




-- fee side ..

DROP VIEW vBSCI_TotalUserFees_PendingSitePayments_FeeBase
GO

CREATE VIEW vBSCI_TotalUserFees_PendingSitePayments_FeeBase
AS

SELECT Name.ID, s.PRODUCT_CODE, SUM(CASE WHEN s.BALANCE IS NULL THEN 0 ELSE s.BALANCE END) AS TOTAL_BALANCE 
FROM Name LEFT JOIN Subscriptions s ON Name.ID = s.ID
WHERE s.BALANCE > 0 


PRODUCT_CODE <> 'BASIC' --AND PRODUCT_CODE NOT LIKE 'D%'
--(
--(left(PRODUCT_CODE,3) = 'NT_') OR (left(PRODUCT_CODE,4) = 'TNC_') OR 
--(left(PRODUCT_CODE,3) = 'FR_') OR (left(PRODUCT_CODE,3) = 'RF_') 
--)



GROUP BY Name.ID, s.PRODUCT_CODE




-- trans side..

DROP VIEW vBSCI_TotalUserFees_PendingSitePayments_TransBase
GO

CREATE VIEW vBSCI_TotalUserFees_PendingSitePayments_TransBase
AS 
SELECT Trans.ST_ID, Trans.AMOUNT, max(TRANS_NUMBER) AS TRANS_NUMBER
FROM Trans 
WHERE Trans.SOURCE_SYSTEM = 'DUES'
AND Trans.JOURNAL_TYPE = 'PAY'
AND Trans.TRANSACTION_TYPE = 'PAY'
AND datediff(dd, Trans.TRANSACTION_DATE, getdate()) < 10
GROUP BY Trans.ST_ID, Trans.AMOUNT


