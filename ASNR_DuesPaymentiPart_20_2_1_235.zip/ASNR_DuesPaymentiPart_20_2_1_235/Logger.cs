﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
//using System.Web.UI.WebControls.WebParts;
//using System.Xml.Linq;

using System.Diagnostics;




namespace BSCI.iPart.BSCIDuesPayments
{
    public enum LogLevel
    {
        Info = 1,
        Warning = 5,
        Error = 9,
        Default = 1


    }

    public class Logger
    {
        public static int lvlToLog = 5;
        public static bool debug = true;


        //public static string logTo = "Diag"; 
        //public static string logTo = "File";
        //public static string logTo = "Console";
        public static string logTo = "Events";


        public static bool inclHeader = true;


        // write INFORMATION logging to Event Log .. set by calling iPart 
        //public static bool EnableDebugOutput = false;

        private static bool appDefined = false;
        //private static string source = "BSCI";
        private static string source = "ASI";
        private static string log = "Application";


        // not using now ..
        public static void WriteLine(string msg)
        {
            WriteLine((int)LogLevel.Default, msg);
        }


        //public static void WriteLine(int lvl, string msg)
        //{
        //    if (lvl < lvlToLog) return;
        //    //
        //    if (!(debug) & (lvl < (int)LogLevel.Error)) return;
        //    //
        //    if (inclHeader & (logTo != "Events"))
        //    {
        //        string lHeader = DateTime.Now.ToString("yyyy-MM-dd @ HH:MM:ss ");
        //        if (lvl < (int)LogLevel.Warning) lHeader += "Info ";
        //        else if (lvl < (int)LogLevel.Error) lHeader += "Warn ";
        //        else lHeader += "Err  ";
        //        LogIt(lHeader + msg, -1);
        //    }
        //    else
        //    {
        //        LogIt(msg, lvl);
        //    }
        //}



        // not using now ..
        public static void WriteLine(int lvl, string msg)
        {
            //if (lvl < lvlToLog) return;
            ////
            //if (!(debug) & (lvl < (int)LogLevel.Error)) return;
            ////
            //if (inclHeader & (logTo != "Events"))
            //{
            //    string lHeader = DateTime.Now.ToString("yyyy-MM-dd @ HH:MM:ss ");
            //    if (lvl < (int)LogLevel.Warning) lHeader += "Info ";
            //    else if (lvl < (int)LogLevel.Error) lHeader += "Warn ";
            //    else lHeader += "Err  ";
            //    LogIt(lHeader + msg, -1);
            //}
            //else
            //{
            //    LogIt(msg, lvl);
            //}

            LogIt(msg, lvl, true);
        }


        // this is the main one I am calling ..
        public static void WriteLine(int lvl, string msg, bool InfoLogging)
        {
            LogIt(msg, lvl, InfoLogging);
        }





        // not using now ..
        public static void WriteLine(int lvl, string msg, object iObj)
        {
            WriteLine(lvl, msg, true);
        }


        //
        // public static void Pause()
        // {
        //     if (debug)
        //     {
        //         System.Console.Write("Hit enter ...");
        //         System.Console.Read();
        //     }
        // }
        //


        private static void LogIt(string msg, int lvl, bool WriteINFOLogging)
        {
            if (logTo == "Diag")
            {
                System.Diagnostics.Debug.WriteLine(msg);
            }
            else if (logTo == "Console")
            {
                // System.Console.WriteLine(msg);
                System.Diagnostics.Debug.WriteLine(msg);
            }
            else if (logTo == "Events")
            {
                //if (!appDefined & (!System.Diagnostics.EventLog.SourceExists(source)))
                //{
                //    System.Diagnostics.EventLog.CreateEventSource(source, log);
                //    appDefined = true;
                //}

                // JW added here fo testing ..
                System.Diagnostics.Debug.WriteLine(msg);


                EventLogEntryType EvtType;

                //writes INFORMATION event ..
                if (lvl == 1)
                {
                    if (WriteINFOLogging)
                    {
                        EvtType = EventLogEntryType.Information;
                        System.Diagnostics.EventLog.WriteEntry(source, "BSCIPayPart: " + msg, EvtType);
                    }
                }
                //writes WARNING event ..
                if (lvl == 5)
                {
                    EvtType = EventLogEntryType.Warning;
                    System.Diagnostics.EventLog.WriteEntry(source, "BSCIPayPart: " + msg, EvtType);
                }
                //writes ERROR event ..
                if (lvl == 9)
                {
                    EvtType = EventLogEntryType.Error;
                    System.Diagnostics.EventLog.WriteEntry(source, "BSCIPayPart: " + msg, EvtType);
                }




                // EventLog.WriteEntry(sSource, sEvent, EventLogEntryType.Warning, 234);
            }
            else if (logTo == "File")
            {
                System.Diagnostics.Debug.WriteLine(msg);
                // System.Console.WriteLine(msg);
            }
        }
    } // end Logger
} // end namespace



//However, note that starting in 15.1 we are starting to move away from log4net in favor of ASP.NET Health Monitoring 
//(which is filterable and more easily redirectable than log4net is, as well as tying into Windows Health Monitoring). 
//There are several base classes in Asi.Providers.HealthMonitoring that can be used for this purpose (or you can roll your 
//own monitoring events, or both):

//AsiWebFailureAuditEvent failureEvent = new AsiWebFailureAuditEvent(
//    ResourceManager.GetPhrase("AccountCreationFailed", "Failed to create new account {0}: {1}.", new string[] { username, ex.Message }),
//    this, AsiAuditEventCode.AccountCreation);
//failureEvent.Raise();

//AsiWebErrorEvent errorEvent = new AsiWebErrorEvent(
//    ResourceManager.GetPhrase("AccountCreationFailed", "Failed to create new account {0}.", new string[] { username }),
//    this, AsiErrorEventCode.Error, ex);
//errorEvent.Raise();

//By default, Health Monitoring error and audit failure events are logged to the Windows Application Event Log, although 
//customers can modify these rules (for example, to log additional events such as audit success, or to log to a different 
//event sink, such as SQL Server).
