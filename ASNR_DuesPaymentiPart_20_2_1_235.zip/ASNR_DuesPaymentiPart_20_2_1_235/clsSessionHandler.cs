﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using Asi;
using Asi.iBO;
using Asi.iBO.ContactManagement;
using Asi.iBO.Commerce;

using System.Collections.Generic;
using System.IO;
using System.Reflection;         // to debug clsSessionHandler


namespace BSCI.iPart.BSCIDuesPayments
{
    public class clsSessionHandler
    {
        // Special BSCI Session Mgmt Class

       


        // Declare a string variable to hold the key name of the session variable
        // and use this string variable instead of typing the key name
        // in order to avoid spelling mistakes

       


        //private static string _SiteUser = "SiteUser";   // ARDC.SiteUser 


        // for loading firm loc drop down ctrl ..
        //private static string _JurisdictionsDict = "JurisdictionsDict";    //Dictionary

       


       // private static string _CCConvFeeMultiplier = "CCConvFeeMultiplier";   // DECIMAL  -  credit card convienience fee multiplier ..

        private static string _DictEmailDetail = "DictEmailDetail";  //Dictionary, IQA columns found

        private static string _iPartProperty_ReceiptFromEmailAddress = "iPartProperty_ReceiptFromEmailAddress";    // receipt email FROM address..

        private static string _iPartProperty_ReceiptCCEmailAddress = "iPartProperty_ReceiptCCEmailAddress";    // receipt email CC address..

        private static string _iPartProperty_ErrorEmailToAddress = "iPartProperty_ErrorEmailToAddress";    // error email TO address..

        //private static string _PayAmtInbound = "PayAmtInbound";   // DECIMAL  -  inbound fee amount ..        
        private static string _TotalFeesFound = "TotalFeesFound";   // DECIMAL  -  for CC payments, fees + conv fee..

        private static string _SHrunningDuesBalance = "SHrunningDuesBalance";   // DECIMAL
        


        //private static string _NumSubsToPay = "NumSubsToPay";   // int -  number of Subscription fee products user is paying for..

        private static string _SubsToPay = "SubsToPay";   // CSubscription[]  -  Subscription fee products user is paying for..used for email...
      
        //private static string _InRegModeFlow = "InRegModeFlow";   // bool
        private static string _NextTargetPage = "NextTargetPage";   // string
        private static string _PrevTargetPage = "PrevTargetPage";   // string


      



        private static string _iMISUser = "iMISUser";   //iBO overhead -  Asi.iBO.IiMISUser iMISUser;
        private static string _iMIS_LoggedIn_UserID = "iMIS_LoggedIn_UserID";   // ID number

        private static string _iMISVersion = "iMISVersion";     //string



        // *****iPart properties, config settings for iMIS CMS..
        private static string _iPartVersion = "iPartVersion";  // set in Assembly information in this VS project .., string




        // BEGIN CMS CONFIG ..
        // These are iPart properties, config settings for iMIS CMS..

        private static string _iPartProperty_InfoDebuggingOn = "iPartProperty_InfoDebuggingOn";   // bool

        private static string _iPartProperty_PageTitle = "iPartProperty_PageTitle";   // string

        private static string _iPartProperty_DoNotRenderInDesignMode = "iPartProperty_DoNotRenderInDesignMode";  // bool

       
        // END CMS CONFIG ..


        public static Dictionary<string, string> DictEmailDetail
        {
            get
            {
                // Check for null first
                if (HttpContext.Current.Session[clsSessionHandler._DictEmailDetail] == null)
                {
                    // if null return empty Dictionary
                    return new Dictionary<string, string>();   ///???????
                }
                else
                {
                    return (Dictionary<string, string>)HttpContext.Current.Session[clsSessionHandler._DictEmailDetail];
                }
            }

            set
            {

                HttpContext.Current.Session[clsSessionHandler._DictEmailDetail] = value;
            }
        }


        // 
        public static string iPartProperty_ReceiptFromEmailAddress
        {
            get
            {
                // Check for null first
                if (HttpContext.Current.Session[clsSessionHandler._iPartProperty_ReceiptFromEmailAddress] == null)
                {
                    // Return an empty string if session variable is null
                    return "jwglass@bscichicago.com";
                }
                else
                {
                    return HttpContext.Current.Session[clsSessionHandler._iPartProperty_ReceiptFromEmailAddress].ToString();
                }
            }

            set
            {
                HttpContext.Current.Session[clsSessionHandler._iPartProperty_ReceiptFromEmailAddress] = value;
            }
        }


        // 
        public static string iPartProperty_ReceiptCCEmailAddress
        {
            get
            {
                // Check for null first
                if (HttpContext.Current.Session[clsSessionHandler._iPartProperty_ReceiptCCEmailAddress] == null)
                {
                    // Return an empty string if session variable is null
                    return "jwglass@bscichicago.com";
                }
                else
                {
                    return HttpContext.Current.Session[clsSessionHandler._iPartProperty_ReceiptCCEmailAddress].ToString();
                }
            }

            set
            {
                HttpContext.Current.Session[clsSessionHandler._iPartProperty_ReceiptCCEmailAddress] = value;
            }
        }
      


        public static string iPartProperty_ErrorEmailToAddress
        {
            get
            {
                // Check for null first
                if (HttpContext.Current.Session[clsSessionHandler._iPartProperty_ErrorEmailToAddress] == null)
                {
                    // Return an empty string if session variable is null
                    return "jwglass@bscichicago.com";
                }
                else
                {
                    return HttpContext.Current.Session[clsSessionHandler._iPartProperty_ErrorEmailToAddress].ToString();
                }
            }

            set
            {
                HttpContext.Current.Session[clsSessionHandler._iPartProperty_ErrorEmailToAddress] = value;
            }
        }
      


        //public static ARDC.clsSiteUser SiteUser
        //{
        //    get
        //    {
        //        // Check for null first
        //        if (HttpContext.Current.Session[clsSessionHandler._SiteUser] == null)
        //        {
        //            // if null Init site user ..   
        //            return null;
        //        }
        //        else
        //        {
        //            return (ARDC.clsSiteUser)HttpContext.Current.Session[clsSessionHandler._SiteUser];
        //        }
        //    }

        //    set
        //    {
        //        HttpContext.Current.Session[clsSessionHandler._SiteUser] = value;
        //    }
        //}





        //public static Dictionary<string, string> JurisdictionsDict
        //{
        //    get
        //    {
        //        // Check for null first
        //        if (HttpContext.Current.Session[clsSessionHandler._JurisdictionsDict] == null)
        //        {
        //            // if null return empty Dictionary                    
        //            return new Dictionary<string, string>();   ///???????
        //        }
        //        else
        //        {
        //            return (Dictionary<string, string>)HttpContext.Current.Session[clsSessionHandler._JurisdictionsDict];
        //        }
        //    }

        //    set
        //    {
        //        HttpContext.Current.Session[clsSessionHandler._JurisdictionsDict] = value;
        //    }
        //}



        //public static int NumSubsToPay
        //{
        //    get
        //    {
        //        // Check for null first
        //        if (HttpContext.Current.Session[clsSessionHandler._NumSubsToPay] == null)
        //        {
        //            // Return if session variable is null ..
        //            return 0;
        //        }
        //        else
        //        {
        //            return (int)HttpContext.Current.Session[clsSessionHandler._NumSubsToPay];
        //        }
        //    }

        //    set
        //    {
        //        HttpContext.Current.Session[clsSessionHandler._NumSubsToPay] = value;
        //    }
        //}



        public static CSubscription[] SubsToPay
        {
            get
            {
                // Check for null first
                if (HttpContext.Current.Session[clsSessionHandler._SubsToPay] == null)
                {
                    // Return if session variable is null ..
                    return null;
                }
                else
                {
                    return (CSubscription[])HttpContext.Current.Session[clsSessionHandler._SubsToPay];
                }
            }

            set
            {
                HttpContext.Current.Session[clsSessionHandler._SubsToPay] = value;
            }
        }



        public static decimal SHrunningDuesBalance
        {
            get
            {
                // Check for null first
                if (HttpContext.Current.Session[clsSessionHandler._SHrunningDuesBalance] == null)
                {
                    // Return if session variable is null ..
                    return 0;
                }
                else
                {
                    return (decimal)HttpContext.Current.Session[clsSessionHandler._SHrunningDuesBalance];
                }
            }

            set
            {
                HttpContext.Current.Session[clsSessionHandler._SHrunningDuesBalance] = value;
            }
        }




        //public static decimal PayAmtInbound
        //{
        //    get
        //    {
        //        // Check for null first
        //        if (HttpContext.Current.Session[clsSessionHandler._PayAmtInbound] == null)
        //        {
        //            // Return if session variable is null ..
        //            return 0;
        //        }
        //        else
        //        {
        //            return (decimal)HttpContext.Current.Session[clsSessionHandler._PayAmtInbound];
        //        }
        //    }

        //    set
        //    {
        //        HttpContext.Current.Session[clsSessionHandler._PayAmtInbound] = value;
        //    }
        //}



        public static decimal TotalFeesFound
        {
            get
            {
                // Check for null first
                if (HttpContext.Current.Session[clsSessionHandler._TotalFeesFound] == null)
                {
                    // Return if session variable is null ..
                    return 0;
                }
                else
                {
                    return (decimal)HttpContext.Current.Session[clsSessionHandler._TotalFeesFound];
                }
            }

            set
            {
                HttpContext.Current.Session[clsSessionHandler._TotalFeesFound] = value;
            }
        }


       



        public static string NextTargetPage
        {
            get
            {
                // Check for null first
                if (HttpContext.Current.Session[clsSessionHandler._NextTargetPage] == null)
                {
                    // Return default page if session variable is null
                    return "attyreg_mainmenu.aspx";
                }
                else
                {
                    return HttpContext.Current.Session[clsSessionHandler._NextTargetPage].ToString();
                }
            }

            set
            {
                HttpContext.Current.Session[clsSessionHandler._NextTargetPage] = value;
            }
        }



        public static string PrevTargetPage
        {
            get
            {
                // Check for null first
                if (HttpContext.Current.Session[clsSessionHandler._PrevTargetPage] == null)
                {
                    // Return default page if session variable is null
                    return "attyreg_mainmenu.aspx";
                }
                else
                {
                    return HttpContext.Current.Session[clsSessionHandler._PrevTargetPage].ToString();
                }
            }

            set
            {
                HttpContext.Current.Session[clsSessionHandler._PrevTargetPage] = value;
            }
        }




        //public static string[] SelectedRecordKey
        //{
        //    get
        //    {
        //        // Check for null first

        //        if (HttpContext.Current.Session[clsSessionHandler._SelectedRecordKey] == null)
        //        {
        //            // Return an empty string if session variable is null
        //            //return string.Empty;

        //            // we are not logged in so login as special guest account 
        //            //return System.Guid.Empty;
        //            string[] array = new string[1];
        //            return array;

        //            //Asi.iBO.ContactManagement.CContactUser.LoginByWebLogin(Asi.Security.AppPrincipal.CurrentIdentity.LoginName);
        //        }
        //        else
        //        {
        //            //return [clsSessionHandler._iMISUser];
        //            return (string[])HttpContext.Current.Session[clsSessionHandler._SelectedRecordKey];
        //        }
        //    }

        //    set
        //    {
        //        HttpContext.Current.Session[clsSessionHandler._SelectedRecordKey] = value;
        //    }
        //}



        //// Asi.Business.BusinessItem
        //public static Asi.Business.BusinessItem SelectedRecord
        //{
        //    get
        //    {
        //        // Check for null first

        //        if (HttpContext.Current.Session[clsSessionHandler._SelectedRecord] == null)
        //        {
        //            // Return an empty string if session variable is null
        //            // create the container (inherits DataSet) .. (using one from UserControlBase control ..)
        //            Asi.Business.BusinessContainer myContainer = new Asi.Business.BusinessContainer("Container");
        //            Asi.Business.BusinessController controller = Asi.Business.BusinessController.NewBusinessController(myContainer, "CsSubscriptions");

        //            Asi.Business.BusinessItem selectedUDrecord;

        //            selectedUDrecord = controller.Add(clsSessionHandler.SelectedRecordKey);

        //            return selectedUDrecord;

        //        }
        //        else
        //        {
        //            //return [clsSessionHandler._iMISUser];
        //            return (Asi.Business.BusinessItem)HttpContext.Current.Session[clsSessionHandler._SelectedRecord];
        //        }
        //    }

        //    set
        //    {
        //        HttpContext.Current.Session[clsSessionHandler._SelectedRecord] = value;
        //    }
        //}






        //public static Asi.Parameters.CommonParameterCollection IQACommParamCollection
        //{
        //    get
        //    {
        //        // Check for null first
        //        if (HttpContext.Current.Session[clsSessionHandler._IQACommParamCollection] == null)
        //        {
        //            // Return an empty param collection if session variable is null                    
        //            return new Asi.Parameters.CommonParameterCollection();
        //        }
        //        else
        //        {
        //            //return [clsSessionHandler._iMISUser];
        //            return (Asi.Parameters.CommonParameterCollection)HttpContext.Current.Session[clsSessionHandler._IQACommParamCollection];
        //        }
        //    }

        //    set
        //    {
        //        HttpContext.Current.Session[clsSessionHandler._IQACommParamCollection] = value;
        //    }
        //}











        //You have to use an httpContext object in your class. Like this:
        //Dim curContext As HttpContext = HttpContext.Current
        //curContext.Session("myDataset") =myDataset

        //private static IiMISUser _iMISUser = (Asi.iBO.IiMISUser)"SelectediMISUser";

        // Declare a static / shared strongly typed property to expose session variable


        public static IiMISUser iMISUser
        {
            get
            {
                // Check for null first

                if (HttpContext.Current.Session[clsSessionHandler._iMISUser] == null)
                {
                    // Return an empty string if session variable is null
                    //return string.Empty;

                    // we are not logged in so login as special guest account 
                    //return Asi.iBO.ContactManagement.CContactUser.LoginByWebLogin(Asi.Security.AppPrincipal.CurrentIdentity.LoginName);
                    return Asi.iBO.ContactManagement.CContactUser.LoginByWebLogin(clsSessionHandler.iMIS_LoggedIn_UserID);
                }
                else
                {
                    //return [clsSessionHandler._iMISUser];
                    return (Asi.iBO.IiMISUser)HttpContext.Current.Session[clsSessionHandler._iMISUser];
                }
            }

            set
            {
                HttpContext.Current.Session[clsSessionHandler._iMISUser] = value;
            }
        }


        public static string iMIS_LoggedIn_UserID
        {
            get
            {
                // Check for null first
                if (HttpContext.Current.Session[clsSessionHandler._iMIS_LoggedIn_UserID] == null)
                {
                    // Return an empty string if session variable is null
                    return string.Empty;
                }
                else
                {
                    return HttpContext.Current.Session[clsSessionHandler._iMIS_LoggedIn_UserID].ToString();
                }
            }

            set
            {
                HttpContext.Current.Session[clsSessionHandler._iMIS_LoggedIn_UserID] = value;
            }
        }



        public static string iMISVersion
        {
            get
            {
                // Check for null first
                if (HttpContext.Current.Session[clsSessionHandler._iMISVersion] == null)
                {
                    // Return an empty string if session variable is null
                    return string.Empty;
                }
                else
                {
                    return HttpContext.Current.Session[clsSessionHandler._iMISVersion].ToString();
                }
            }

            set
            {
                HttpContext.Current.Session[clsSessionHandler._iMISVersion] = value;
            }
        }


        public static string iPartVersion
        {
            get
            {
                // Check for null first
                if (HttpContext.Current.Session[clsSessionHandler._iPartVersion] == null)
                {
                    // Return an empty string if session variable is null
                    return string.Empty;
                }
                else
                {
                    return HttpContext.Current.Session[clsSessionHandler._iPartVersion].ToString();
                }
            }

            set
            {
                HttpContext.Current.Session[clsSessionHandler._iPartVersion] = value;
            }
        }






        // BEGIN CMS CONFIG ..

        public static bool iPartProperty_InfoDebuggingOn
        {
            get
            {
                // Check for null first
                if (HttpContext.Current.Session[clsSessionHandler._iPartProperty_InfoDebuggingOn] == null)
                {
                    // Return false if session variable is null
                    return false;
                }
                else
                {
                    return (bool)HttpContext.Current.Session[clsSessionHandler._iPartProperty_InfoDebuggingOn];
                }
            }

            set
            {
                HttpContext.Current.Session[clsSessionHandler._iPartProperty_InfoDebuggingOn] = value;
            }
        }


        public static bool iPartProperty_DoNotRenderInDesignMode
        {
            get
            {
                // Check for null first
                if (HttpContext.Current.Session[clsSessionHandler._iPartProperty_DoNotRenderInDesignMode] == null)
                {
                    // Return false if session variable is null
                    return false;
                }
                else
                {
                    return (bool)HttpContext.Current.Session[clsSessionHandler._iPartProperty_DoNotRenderInDesignMode];
                }
            }

            set
            {
                HttpContext.Current.Session[clsSessionHandler._iPartProperty_DoNotRenderInDesignMode] = value;
            }
        }




        public static string iPartProperty_PageTitle
        {
            get
            {
                // Check for null first
                if (HttpContext.Current.Session[clsSessionHandler._iPartProperty_PageTitle] == null)
                {
                    // Return an empty string if session variable is null
                    return string.Empty;
                }
                else
                {
                    return HttpContext.Current.Session[clsSessionHandler._iPartProperty_PageTitle].ToString();
                }
            }

            set
            {
                HttpContext.Current.Session[clsSessionHandler._iPartProperty_PageTitle] = value;
            }
        }




        // END CMS CONFIG ..




    }
}
