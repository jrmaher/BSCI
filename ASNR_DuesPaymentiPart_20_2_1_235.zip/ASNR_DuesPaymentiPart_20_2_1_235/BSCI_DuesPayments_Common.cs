﻿
using System;
using System.Runtime.Serialization;
using Asi.Business.ContentManagement;
using Asi.Business.ContentManagement.ContentType;
using System.Web;
using Asi;
using Asi.iBO;
using Asi.Security;
using System.Net.Mail;





namespace BSCI.iPart.BSCIDuesPayments
{

    /// <summary>
    /// This is special class to keep code that is common for both: Display and Configure page.
    /// </summary>


    /// <summary>
    /// Implements base logic for the BSCIDuesPayments iPart.
    /// </summary>
    /// 
    [DataContract(Name = "BSCI_BSCIDuesPayments_iPart")]
    public class BSCI_BSCIDuesPayments_iPart : ContentItem
    {
        

        #region Constructors

        /// <summary>
        /// Creates a new BSCI_BSCIDuesPayments_iPart object.
        /// </summary>
        public BSCI_BSCIDuesPayments_iPart()
            : base()
        {
           
        }

        /// <summary>
        /// Creates a new BSCI_BSCIDuesPayments_Common object.
        /// </summary>
        /// <param name="contentKey"></param>
        public BSCI_BSCIDuesPayments_iPart(Guid contentKey) : base(contentKey) { }

        #endregion


        #region Properties

        /// <summary>
        /// Gets the ContentTypeKey for the ContentTypeRegistry object that represents this content type.
        /// </summary>
        public override Guid ContentTypeKey
        {
            get
            {
                // TODO: Define your Content Type in iMIS (Content Manager->Maintenance->Content types)
                // TODO: Once the Content Type is defined, copy and paste its ContentKey value here.
                return new Guid("faac40ad-f1de-4beb-bda4-9bca4676d41c");
            }
        }


       

        /// <summary>
        /// Gets or sets ..
        /// </summary>
        [DataMember(Name = "HandledGatewayErrorCodes")]
        public string HandledGatewayErrorCodes { get; set; }


        /// <summary>
        /// Gets or sets the iMIS short-cut name for redirection after task ..
        /// </summary>
        [DataMember(Name = "Redirect_ShortCut")]
        public string Redirect_ShortCut { get; set; }


       

        /// <summary>
        /// The path to debug output text file Must have Network Admin R/W.
        /// </summary>

        [DataMember(Name = "ARCashAccountEntity")]
        public string ARCashAccountEntity { get; set; }

        /// <summary>
        /// The path to debug output text file Must have Network Admin R/W.
        /// </summary>

        [DataMember(Name = "ReceiptFromEmailAddress")]
        public string ReceiptFromEmailAddress { get; set; }


        /// <summary>
        /// The path to debug output text file Must have Network Admin R/W.
        /// </summary>

        [DataMember(Name = "ReceiptCCEmailAddress")]
        public string ReceiptCCEmailAddress { get; set; }


        /// <summary>
        /// Gets or sets the email address to send errors.. 
        /// </summary>
        [DataMember(Name = "ErrorEmailToAddress")]
        public string ErrorEmailToAddress { get; set; }



        #endregion Properties



        #region Common Declarations

        /// <summary>
        /// Struct to store config Details for Multi Instance Tables
        /// </summary>
        //public struct stUDTMultiInstanceDetails
        //{
        //    public string TableName;
        //    public System.Collections.ArrayList Fields; // Stores ArrayList of stUDTFieldInfo
        //    public int Index;
        //}

        /// <summary>
        /// Special Class to describe all Required Settings/Properties for Single and Multi Instance fields (Combined from two different classes)
        /// </summary>
        //public struct stUDTGenericFieldInfo
        //{
        //    // General Fields
        //    public int Index; // Applies to Both Single and Multi Instance
        //    public string Field_Name; // Applies to Both Single and Multi Instance
        //    public string Prompt; // Applies to Both Single and Multi Instance
        //    public bool ReadOnly; // Applies to Both
        //    public string DisplayFormat; // Applies to both Single and Multi Instance
        //    public bool UseBox; // Applies to the CHAR with Validation Tables. Display Radio Buttons/Checboxes instead of DropDownloist or List. Applies to both Single and Multi Instance

        //    // Single Instance only fields
        //    public string Table_Name; // Only applies to the Single Instance Tables, for Multi it is EMPTY
        //    public bool NewLine; // Only applies to Single Instance, for Multi - FALSE
        //    public bool DipslayOnlySelected; // Applies only to Single Instance. For Multi it is FALSE

        //    // Multi Instance Only Fields
        //    public string Type; // Applies only to Multi Instance
        //    public int FieldLength;
        //    public string ValidationTable;
        //    public bool MultiSelect;


        //}

        #endregion


        #region Generate View for Single Instance iMIS UDTs

        /// <summary>
        /// Private Method to display Single Instance UDT Info.
        /// </summary>
        /// <param name="Table_name">Table Name to Display</param>
        /// <param name="Field_name">Field Name To display </param>
        /// <param name="Prompt">Prompt to use</param>
        /// <param name="iMISID">IMIS ID to display Records for</param>
        /// <returns>PANEL with all information displayed</returns>
        /// 
        //private Panel GenerateUDTFieldDisplayControls(stUDTGenericFieldInfo UDTDetails, string iMISID, Asi.iBO.ContactManagement.CContact iMISContact, System.Data.DataRow DBRow, eDipslayMode DisplayMode)
        //{
        //    Panel _Results = new Panel();
        //    Label _lbl = new Label();
        //    Asi.iBO.ContactManagement.CExtTable _Table = null;
        //    Asi.iBO.ContactManagement.CExtField _Field = null;
        //    Asi.iBO.ContactManagement.CExtTable _ContactTable = null;
        //    Asi.iBO.ContactManagement.CExtField _ContactField = null;
        //    string _value = "NA";
        //    Image _img = new Image();
        //    decimal _dectmp;
        //    int _inttmp;
        //    DateTime _dttmp;
        //    string _strtmp;

        //    bool useSingle = false;


        //    if (iMISContact != null)
        //        useSingle = true;

        //    if (useSingle)
        //    {
        //        // First of all we need to get our table
        //        _Table = Asi.iBO.iboAdmin.ReferenceData.GetExtTableDefinition(UDTDetails.Table_Name);
        //        if (_Table != null)
        //            _Field = _Table.GetField(UDTDetails.Field_Name);
        //        if (_Table != null && _Field != null)

        //        }
        //    }
        // return _Results;
        //}





        #endregion




        #region ASI iPart Methods

        /// <summary>
        /// Reads current Property values
        /// </summary>
        /// <returns></returns>
        public override ContentParameterCollection GetCurrentParameterValues()
        {
            ContentParameterCollection collection = base.GetCurrentParameterValues();      
            collection.Add("ARCashAccountEntity", ARCashAccountEntity ?? string.Empty);
            collection.Add("Redirect_ShortCut", Redirect_ShortCut ?? string.Empty);
            collection.Add("HandledGatewayErrorCodes", HandledGatewayErrorCodes ?? string.Empty);
            collection.Add("ReceiptFromEmailAddress", ReceiptFromEmailAddress ?? string.Empty);
            collection.Add("ReceiptCCEmailAddress", ReceiptCCEmailAddress ?? string.Empty);
            collection.Add("ErrorEmailToAddress", ErrorEmailToAddress ?? string.Empty);	// string example..
            return collection;
        }


        

        /// <summary>
        /// Configure and set display for CONFIGURATION PAGE
        /// </summary>
        /// <param name="ap"></param>
        public override void ConfigureAtomProperty(Asi.Atom.AtomProperty ap)
        {
            base.ConfigureAtomProperty(ap);

            switch (ap.Name)
            {                            
                case "ARCashAccountEntity":
                    ap.Caption = Asi.ResourceManager.GetPhrase("Asi.Web.iParts.ARCashAccountEntity", "AR Cash Account Entity");
                    break;
                case "Redirect_ShortCut":
                    ap.Caption = Asi.ResourceManager.GetPhrase("Asi.Web.iParts.Redirect_ShortCut", "Enter name of iMIS Shortcut to redirect to after task:");
                    break;
                case "HandledGatewayErrorCodes":
                    ap.Caption = Asi.ResourceManager.GetPhrase("Asi.Web.iParts.HandledGatewayErrorCodes", "Enter list of number codes that allow user to re-pay and that this iPart has code to handle (all other codes fail payment):");
                    break;
                // receipt email FROM address ..
                case "ReceiptFromEmailAddress":
                    ap.Caption = Asi.ResourceManager.GetPhrase("Asi.Web.iParts.ReceiptFromEmailAddress", "Receipt 'FROM' email address.");
                    if (ap.Value == null)
                        ap.Value = "tcheng@asnr.org";
                    break;
                // receipt email FROM address ..
                case "ReceiptCCEmailAddress":
                    ap.Caption = Asi.ResourceManager.GetPhrase("Asi.Web.iParts.ReceiptCCEmailAddress", "Receipt 'CC email address.");
                    if (ap.Value == null)
                        ap.Value = "tcheng@asnr.org";
                    break;
                // error email TO address ..
                case "ErrorEmailToAddress":
                    ap.Caption = Asi.ResourceManager.GetPhrase("Asi.Web.iParts.ErrorEmailToAddress",
                        "Error 'TO' email address.");
                    if (ap.Value == null)
                        ap.Value = "tcheng@asnr.org";
                    break;
                default:
                    break;

            }
        }

        #endregion



        #region BSCI Methods


        /// <summary>
        /// utility function, spins up iPart overhead..sets iMIS version and initializes iBO Admin, as well as gets logged in user iMIS ID ..
        /// </summary>
        /// <returns></returns>
        public void Init_iPart()
        {
            System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();
            System.Diagnostics.FileVersionInfo fvi = System.Diagnostics.FileVersionInfo.GetVersionInfo(assembly.Location);
            clsSessionHandler.iPartVersion = fvi.ProductVersion;
            InitiBO();
            clsSessionHandler.iMIS_LoggedIn_UserID = Asi.Security.Utility.SecurityHelper.LoggedInImisId;
        }





        /// <summary>
        /// Sends email about error from iPart ..
        /// Exception type argument is string, derived from System.Exception...
        /// </summary>
        public void SendErrorEmail(string _ExMsg)
        {
            string ip = HttpContext.Current.Request.UserHostAddress;
            System.Web.HttpBrowserCapabilities browser = HttpContext.Current.Request.Browser;

            //string Cookies = HttpContext.Current.Request.Cookies.ToString();
            string QueryString = HttpContext.Current.Request.QueryString.ToString();
            string IsSecureConnection = HttpContext.Current.Request.IsSecureConnection.ToString();
            string ServerVariables = HttpContext.Current.Request.ServerVariables.ToString();

            //Asi.Web.UI.IUserControl ctrl = (Asi.Web.UI.IUserControl)page;
            //string hh = ctrl.SubjectName;

            SmtpClient smtpClient = new SmtpClient();
            System.Net.Mail.MailMessage msg = new System.Net.Mail.MailMessage();

            // mail server config..
            // smtpClient.Host = ARDCGlobals.SMTP_SERVER;
            // int int_PortNum = Convert.ToInt32(ARDCGlobals.SMTP_SERVER_PORT);
            // smtpClient.Port = int_PortNum;

            //CODE
            MailAddress fromAddress = new MailAddress(clsSessionHandler.iPartProperty_ErrorEmailToAddress);
            msg.From = fromAddress;


            //// process email addresses from web.config
            //System.Configuration.AppSettingsReader configurationAppSettings = new System.Configuration.AppSettingsReader();
            //string _TOs = "";
            //string _CCs = "";
            //_TOs = configurationAppSettings.GetValue("ERROREMAIL_TO", typeof(string)).ToString();
            //_CCs = configurationAppSettings.GetValue("ERROREMAIL_CC", typeof(string)).ToString();
            //string[] workthroughTOs = _TOs.Split(',');
            //foreach (string add in workthroughTOs)
            //{
            //    msg.To.Add(add);
            //}
            //string[] workthroughCCs = _CCs.Split(',');
            //foreach (string addcc in workthroughCCs)
            //{
            //    msg.To.Add(addcc);
            //}
            ////

            // CODE
            msg.To.Add(clsSessionHandler.iPartProperty_ErrorEmailToAddress);

            msg.IsBodyHtml = true;

            msg.Subject = "BSCI Payment iPart Handled Error";

            string _msgBody = string.Empty;
            _msgBody = "Date: " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString()

                   + "<br/><br/>Page or Ctrl: BSCI Payment iPart"
                   + "<br/><br/>IP: " + ip
                   + "<br/><br/>QueryString: " + QueryString
                   + "<br/><br/>IsSecureConnection: " + IsSecureConnection
                   + "<br/><br/>Browser Type: " + browser.Type.ToString()
                    + "<br/><br/>Browser Name: " + browser.Browser
                     + "<br/><br/>Browser Version: " + browser.Version.ToString()
                      + "<br/><br/>Browser Platform: " + browser.Platform.ToString()
                       + "<br/><br/>Is Crawler: " + browser.Crawler.ToString()
                        + "<br/><br/>Supports Cookies: " + browser.Cookies.ToString()
                         + "<br/><br/>Supports JavaScript: " + browser.EcmaScriptVersion.ToString();

            _msgBody += "<br/><br/>User ID: " + clsSessionHandler.iMIS_LoggedIn_UserID;

            _msgBody += "<br/><br/>" + _ExMsg;

            msg.Body = _msgBody;

            try
            {
                smtpClient.Send(msg);
            }
            catch (Exception _Ex)
            {
                string _ErrorMsgBody = "BSCI Payment iPart Error (SendErrorEmail): ";

                if (_Ex.Message != null)
                    _ErrorMsgBody += "Error Message: " + _Ex.Message.ToString();

                if (_Ex.InnerException != null)
                    _ErrorMsgBody += "; Error Inner Exception: " + _Ex.InnerException.ToString();

                if (_Ex.Source != null)
                    _ErrorMsgBody += "; Error Source: " + _Ex.Source.ToString();

                _ErrorMsgBody += "; ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; ";

                Logger.WriteLine(9, _ErrorMsgBody, true);
            }
            finally
            {
            }
        }






        /// <summary>
        /// Special Method to replace ASI iBO method - IBO Missed Substitute values
        /// </summary>
        /// <param name="LookupCode">General Lookup Table Name</param>
        /// <returns>KeyValuePair Array of values with Code replaced by Substitute value (Expansion) if necessary</returns>
        public Asi.iBO.KeyValuePair[] GetLookupCodeDescription(string LookupTableKey)
        {
            //First get Original Lookup from iMIS            
            Asi.iBO.KeyValuePair[] _lookuplist = Asi.iBO.iboAdmin.ReferenceData.GetLookupCodeDescription(LookupTableKey);
            string _SubstCode = "";
            bool _flag = false;
            // Check if we have List
            if (_lookuplist != null && _lookuplist.Length != 0)
            {
                for (int i = 0; i < _lookuplist.Length; i++)
                {
                    _flag = Asi.iBO.iboAdmin.ReferenceData.CheckLookupCode(_lookuplist[i].Key, LookupTableKey, ref _SubstCode);
                    // If we have Substitute then We should use Substitute Code (Expansion) instead of the CODE
                    if (_SubstCode != "")
                        _lookuplist[i].Key = _SubstCode;
                }
            }

            return _lookuplist;

        }


        /// <summary>
        /// Replacement for ASI iBO method - Lookups Description by the code and (or) Substitute(Expansion)
        /// </summary>
        /// <param name="LookupTableKey">General Lookup Table Name</param>
        /// <param name="LookupCode">Lookup Code or Substitute</param>
        /// <returns>Description matching given code.</returns>
        public string GetLookupDescription(string LookupTableKey, string LookupCode)
        {
            string _result = "";
            // Get Fixed Lookup
            Asi.iBO.KeyValuePair[] _LookupList = GetLookupCodeDescription(LookupTableKey);
            if (_LookupList != null && _LookupList.Length != 0)
            {
                foreach (Asi.iBO.KeyValuePair _pair in _LookupList)
                {
                    if (_pair.Key == LookupCode)
                    {
                        _result = _pair.Value;
                        break;
                    }
                }
            }

            return _result;

        }



        /// <summary>
        /// Method to emulate VB function called REDIM
        /// </summary>
        /// <param name="arr">Array to Resize</param>
        /// <param name="length">New Array Size</param>
        public void ReDim(ref string[] arr, int length)
        {
            string[] arrTemp = new string[length];
            if (arr == null)
                arr = new string[1];

            if (length > arr.Length)
            {
                Array.Copy(arr, 0, arrTemp, 0, arr.Length);
                arr = arrTemp;
            }
            else
            {
                Array.Copy(arr, 0, arrTemp, 0, length);
                arr = arrTemp;
            }
        }


        /// <summary>
        /// Useful generic function - returns ID of currently logged in user
        /// </summary>
        /// <returns></returns>
        public string GetLoggedinIMISID()
        {
            string _id = "";
           
            try
            {   // SS change 7/8/15
                // if (Asi.Security.AppPrincipal.CurrentIdentity.IsAuthenticated && Asi.Security.AppPrincipal.CurrentIdentity.ContactMaster != "")
                  // if (Asi.Security.AppPrincipal.CurrentIdentity.IsAuthenticated && Asi.Security.AppPrincipal.CurrentIdentity.LoginUserId != "")
                if (Asi.Security.AppPrincipal.CurrentIdentity.IsAuthenticated && Asi.Security.AppPrincipal.CurrentIdentity.UserId != "")
                {
                   // _id = Asi.Security.AppPrincipal.CurrentIdentity.ContactMaster;
                   
                    _id = Asi.Security.AppPrincipal.CurrentPrincipal.AppIdentity.LoginIdentity;
                  //  _id = "15016";
                }
            }
            catch { }
            return _id;
        }



       

        /// <summary>
        /// Useful generic function - returns ID of currently logged-in USER..
        /// </summary>
        /// <returns></returns>
        public string GetSelectediMISID()
        {
            return Asi.Security.Utility.SecurityHelper.LoggedInImisId;
        }





        /// <summary>
        /// Useful generic function - returns ID of currently Selected user (it may be different from currently logged in USER)
        /// </summary>
        /// <returns></returns>
        public void SetSelectediMISID(string iMISID, HttpResponse _Response)
        {
            string _id = "";
            Secure _tool = new Secure();
            _id = _tool.Encrypt(iMISID);
            _Response.Cookies["UserID"].Value = _id;
        }



       


       

        public void InitiBO()
        {
            //Initialize the iBO application
            if (!iboAdmin.IsSystemInitialized)
            {
                iboAdmin.InitializeSystem();
            }

            clsSessionHandler.iMISVersion = iboAdmin.SystemConfig.iMISVersion.ToString();
        }



        #endregion


        #region Static Methods

        #endregion


    }

}
