﻿using System;
// using System.IO;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
// using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Asi.iBO;
using Asi.iBO.ContactManagement;
using Asi.iBO.ContentManagement;
using Asi.iBO.Commerce;
using Asi.iBO.Financials;
using Asi.Web.UI.WebControls;
using System.Net.Mail;
using System.Globalization;
using System.Threading;



//namespace BSCI.iPart.BSCIDuesPayments
namespace BSCI.iPart.BSCIDuesPayments
{


    /// <summary>
    /// Main iPart Display Class
    /// </summary>
    public partial class BSCI_BSCIDuesPayments_Display : Asi.Web.UI.ContentItemDisplayBase
    {



     

        #region Common Declarations


        protected string entityCode
        {
            // this gets/sets selected ID ..
            get
            {
                String _strRawURL = HttpContext.Current.Request.RawUrl.ToString();
                if (_strRawURL.Contains("entity"))
                    return Request.Params["entity"];
                return string.Empty;
            }
        }

        BSCI_BSCIDuesPayments_iPart _BSCIPartUtils = new BSCI_BSCIDuesPayments_iPart();


     


        // JW ADDED 11/9/15..  for stock generic gateway response values..
        protected string _gtway_AuthorizationCode;
        protected Asi.iBO.Financials.CardProcessingStatus _gtway_CardProcessingStatus;   // Authorized, Captured, Deferred, Manual ..
        protected string _gtway_ResponseMessage;  // contains response code, reason code and reason text  
        protected string _gtway_ReferenceID;   // ReferenceId     
        protected string _gtway_Result;   // Result
        protected string _gtway_iMISCashAcctUsed;
        protected string _gtway_iMISCashAcctUsedDescription;
        // may be PayFlow or extended ..
        protected string _gtway_TransID;    // TransactionId
        protected decimal _gtway_PayAmount;

        string _imisID = "";        
       
       // Asi.iBO.IiMISUser _user = Asi.iBO.ContactManagement.CContactUser.LoginByWebLogin(Asi.Security.AppPrincipal.CurrentIdentity.LoginName);
        Asi.iBO.IiMISUser _iMISUser = Asi.iBO.ContactManagement.CContactUser.LoginByWebLogin(Asi.Security.AppPrincipal.CurrentIdentity.LoginName);


        string txtDuesAlreadyPaid = "";
        
       // private string path = @System.Configuration.ConfigurationManager.AppSettings["logFilePath"].ToString();

        protected System.Web.UI.WebControls.Button btnPay;
        protected System.Web.UI.WebControls.Button btnFinish;
        protected System.Web.UI.WebControls.TextBox Entity;
        protected System.Web.UI.WebControls.TextBox iMISIDText;
        protected System.Web.UI.WebControls.TextBox Amount;
        protected System.Web.UI.WebControls.TextBox se;
        protected System.Web.UI.WebControls.TextBox FirstName;
        protected System.Web.UI.WebControls.DropDownList CardType_DropDownList;
        protected System.Web.UI.WebControls.TextBox LastName;
        protected System.Web.UI.WebControls.TextBox CCCardNumber;
        protected System.Web.UI.WebControls.TextBox Address1Txt;
        protected System.Web.UI.WebControls.TextBox City;
        protected System.Web.UI.WebControls.TextBox State;
        protected System.Web.UI.WebControls.TextBox Zip;
        protected System.Web.UI.WebControls.TextBox Country;
        protected System.Web.UI.WebControls.TextBox txtResult;
        protected System.Web.UI.WebControls.TextBox txtEmailAddress;
        //protected Telerik.Web.UI.RadDatePicker Expiration_RadDatePicker;
        protected System.Web.UI.WebControls.DropDownList ddlYear;
        protected System.Web.UI.WebControls.DropDownList ddlMonth;
        protected System.Web.UI.WebControls.Label lblAddress1Txt;
        protected System.Web.UI.WebControls.Label lblZip;
        protected System.Web.UI.WebControls.Label lblCountry;
        protected System.Web.UI.WebControls.Label lblCity;
        protected System.Web.UI.WebControls.Label lblState;
        protected System.Web.UI.WebControls.Label lblCCCardNumber;
        protected System.Web.UI.WebControls.Label lblCardType_DropDownList;
        protected System.Web.UI.WebControls.Label lblFirstName;
        protected System.Web.UI.WebControls.Label lblLastName;
        protected System.Web.UI.WebControls.Label lblEmail;
        private ArrayList _checkBoxes = new ArrayList();
        
      

       // CActivity[] duesHistory;



        #endregion



        #region BSCI Part Overrides and Event Handlers



        #endregion





        #region ASI Part (UserControlBase) Overrides and Part Event Handlers


        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);


            // if ((DoNotRenderInDesignMode) && (IsContentDesignMode))
            if (IsContentDesignMode)
                HideContent = true;
            else
                HideContent = false;
            

        }


        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            //// set up other display elements ..       
            //if (!IsContentDesignMode)
            //{
            //}

        }


        /// <summary>
        /// This Event is fired every time when page is loaded.
        /// However if page is displayed in Design mode the property values will not have 
        /// correct values. To get "correct" (newest) property values you should use DataBind event.
        /// HOWEVER in runtime this event will have all correct property values.
        /// </summary>
        /// <param name="e"></param>       
        protected override void OnLoad(EventArgs e)
        {          
            try
            { 
            base.OnLoad(e);

            EnsureChildControls();
            
            ddlYearFill();
          
            // set url for button using iMIS short-cut..                 
            System.Guid wKey = Asi.AppContext.CurrentContext.WebsiteKey;               
            var dummycollection = new NameValueCollection();
            string url = Asi.Web.Utilities.GetShortcutUrl(dummycollection, wKey, Redirect_ShortCut);
            //string url = Asi.Web.Utilities.GetShortcutUrl(new NameValueCollection(Request.QueryString), wKey, Redirect_ShortCut);
            asibtn_Finish.NavigateUrl = url;


            if ((!IsPostBack) && (!IsContentDesignMode))
            {
                // runs iPart overhead routine in common iPart class ..
                //BSCI_BSCIDuesPayments_iPart _BSCIPartUtils = new BSCI_BSCIDuesPayments_iPart();

                // init iPart - see notes in that class
                //_BSCIPartUtils.Init_iPart();               

                // set default user display               
                SetDefaultDisplay(); 

            }
            if (IsPostBack)
            {
                // set default user display               
                SetDefaultDisplay();
            }

            }
            catch (Exception _Ex)
            {       
                string _msgBody = "BSCI Payment iPart Error (OnLoad): ";

                if (_Ex.Message != null)
                    _msgBody += "Error Message: " + _Ex.Message.ToString();

                if (_Ex.InnerException != null)
                    _msgBody += "; Error Inner Exception: " + _Ex.InnerException.ToString();

                if (_Ex.Source != null)
                    _msgBody += "; Error Source: " + _Ex.Source.ToString();

                _msgBody += "; ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; ";

                Logger.WriteLine(9, _msgBody, true);
                _BSCIPartUtils.SendErrorEmail(_msgBody);

                // show error to user..
                asilbl_ErrorMsg.Text = _msgBody;
                asilbl_ErrorMsg.Visible = true;
            }
            finally
            {
            }
            
        }


       

         protected override void OnInit(EventArgs e) 
        {
            if (!this.IsPostBack)
            {
                // runs iPart overhead routine in common iPart class ..
                BSCI_BSCIDuesPayments_iPart _BSCIPartUtils = new BSCI_BSCIDuesPayments_iPart();

                // init iPart - see notes in that class
                _BSCIPartUtils.Init_iPart();    

                // read-in iPart property values; 
                InitLoadCMSConfigSettings();

                base.OnInit(e);

                EnsureChildControls();
            }


            Entity.Text = "";
            if (entityCode != string.Empty)
            {
                Entity.Text = entityCode;
                Entity.BorderStyle = BorderStyle.None;
            }

            

            string _total;
            try
            {
                _total = (duesBuilder(Entity.Text, Entity.Text).ToString());
            }
            catch
            {
                _total = "";
            }


            if (clsSessionHandler.TotalFeesFound == 0)
            {
                // display success panel ...
                // to display via style ..
                //pan_finish.Style.Remove("display");
               // pan_finish.Style.Add("display", "inline");
                pan_finish.Visible = true;
                ltl_DoNotAllowPayment.Visible = true;

                // to hide via style ..
               // pan_main.Style.Add("display", "none");
                pan_main.Visible = false;
            }


            if (_total == "" || _total == "0" || _total == "0.000") //Does not owe fee product.
            {
                 // display success panel ...
                // to display via style ..
                // pan_finish.Style.Remove("display");
                //pan_finish.Style.Add("display", "inline");
               pan_finish.Visible = true;
               ltl_DoNotAllowPayment.Visible = true;    

                // to hide via style ..
                //pan_main.Style.Add("display", "none");
               pan_main.Visible = false;
                         
            }

               
            
           }


        #endregion



        #region iPart Properties

      


         public string ARCashAccountEntity
         {
             get
             {
                 if (ViewState["ARCashAccountEntity"] == null)
                     return string.Empty;

                 return (string)ViewState["ARCashAccountEntity"];
             }
             set
             {
                 ViewState["ARCashAccountEntity"] = value;
             }
         }



         public string ReceiptFromEmailAddress
         {
             get
             {
                 if (ViewState["ReceiptFromEmailAddress"] == null)
                     return string.Empty;

                 return (string)ViewState["ReceiptFromEmailAddress"];
             }
             set
             {
                 ViewState["ReceiptFromEmailAddress"] = value;
             }
         }


         public string ReceiptCCEmailAddress
         {
             get
             {
                 if (ViewState["ReceiptCCEmailAddress"] == null)
                     return string.Empty;

                 return (string)ViewState["ReceiptCCEmailAddress"];
             }
             set
             {
                 ViewState["ReceiptCCEmailAddress"] = value;
             }
         }
        

         /// <summary>
         /// email address for errors..
         /// </summary>
         public string ErrorEmailToAddress
         {
             get
             {
                 if (ViewState["ErrorEmailToAddress"] == null)
                     return string.Empty;

                 return (string)ViewState["ErrorEmailToAddress"];
             }
             set
             {
                 ViewState["ErrorEmailToAddress"] = value;
             }
         }

         /// <summary>
         /// iMIS short-cut for redirect ..
         /// </summary>
         public string Redirect_ShortCut
         {
             get
             {
                 if (ViewState["Redirect_ShortCut"] == null)
                     return string.Empty;

                 return (string)ViewState["Redirect_ShortCut"];
             }
             set
             {
                 ViewState["Redirect_ShortCut"] = value;
             }
         }

         /// <summary>
         ///  ..
         /// </summary>
         public string HandledGatewayErrorCodes
         {
             get
             {
                 if (ViewState["HandledGatewayErrorCodes"] == null)
                     return string.Empty;

                 return (string)ViewState["HandledGatewayErrorCodes"];
             }
             set
             {
                 ViewState["HandledGatewayErrorCodes"] = value;
             }
         }



        #endregion



        #region iMIS Specific Overrides

        /// <summary>
        /// Create the appropriate object
        /// </summary>
        /// <returns></returns>
        public override Asi.Business.ContentManagement.ContentItem CreateContentItem()
        {
            //var item = new BSCI.iPart.BSCIDuesPayments.Common {ContentItemKey = ContentItemKey};
            //BSCI_BSCIDuesPayments_iPart
            var item = new BSCI_BSCIDuesPayments_iPart { ContentItemKey = ContentItemKey };
            return item;
        }


        #endregion




        #region BSCI Part Methods



        protected void SetDefaultDisplay()
        {
            // re-set for default display
            //asilbl_iPartConfigTitle.Text = this.PartTitle;
            asilbl_ErrorMsg.Visible = false;
            asilbl_ErrorMsg.Text = "";




            if (clsSessionHandler.TotalFeesFound == 0)
            {   
                // display finish panel ...              
                pan_finish.Visible = true;
                ltl_DoNotAllowPayment.Visible = true;
               
                pan_main.Visible = false;
                return;
            }
            else
            {
                pan_finish.Visible = false;
            }
                

            

            // 1st review ... any pending payments...?   

            //string _IDFound = string.Empty;                   
            //string sql = "select ID FROM vARDC_TotalIndAttyFees_PendingSitePayments where vARDC_TotalIndAttyFees_PendingSitePayments.ID = '" + clsSessionHandler.iMIS_LoggedIn_UserID + "'";

            //System.Data.DataTable allData = new System.Data.DataTable();
            //using (Asi.Data.DataServer server = new Asi.Data.DataServer())
            //{
            //    System.Data.DataSet ds = server.ExecuteDataSet(System.Data.CommandType.Text, sql);
            //    allData = ds.Tables[0];
            //}   

            //// make sure we have only 1 record...
            //if (allData.Rows.Count != 1)
            //{
            //     // didn't find user's record, have user call office..
            //     //asilbl_ErrorMsg.Text = "Your email of record could not be confirmed, please check your attorney number and try again, or contact the ARDC registration department by telephone at (312) 565-2600 or, from within Illinois, at (800) 826-8625.";
            //     //asilbl_ErrorMsg.Visible = true;
            //     //return;
            //     string fhjuf = "dd";
            //}
            //else
            //{
            //    // user record found, get users email address ..
            //    foreach (System.Data.DataRow dRow in allData.Rows)
            //    {
            //        _IDFound = dRow[0].ToString();
            //    }

            //}

            //if (_IDFound.Length > 1)
            //{
            //    // have a pending payment, batch NOT posted...
            //    ltl_DoNotAllowPayment.Visible = true;
            //    return;
            //}


            bool _LogCheck = CheckPaymentLogging();

            if (_LogCheck)
            { 
                // have a pending payment, batch NOT posted...
                pan_finish.Visible = true;
                ltl_DoNotAllowPayment.Visible = true;

                pan_main.Visible = false;
            }


        }




        // gets/sets all config values from CMS or as Solo 
        public void InitLoadCMSConfigSettings()
        {
            // read-in iPart property values; also could possibly use ASIs CMS GetCurrentParameterValues()  

            string hhyy = "ee";


            clsSessionHandler.iPartProperty_ReceiptFromEmailAddress = ReceiptFromEmailAddress;
            clsSessionHandler.iPartProperty_ReceiptCCEmailAddress = ReceiptCCEmailAddress;
            clsSessionHandler.iPartProperty_ErrorEmailToAddress = ErrorEmailToAddress;
            //SessionHandlerBSCIBSCIInsertEditActivity.iPartProperty_EnableDebugPanel = EnableDebugPanel;
        }





        //public void asibtn_Finish_Click(Object sender, EventArgs e)
        //{



        //}



        public void btnPay_Click(Object sender, EventArgs e)
        {
            try
            {
            
            btnPay.Enabled = false;
            
            BSCI_BSCIDuesPayments_iPart _utils = new BSCI_BSCIDuesPayments_iPart();             
                   
            
           // url = "~/"+ Entity.Text.ToString() + "/"  + Entity.Text.ToString() + "_MemberServices/MyAccount/Billing/iMIS/ContentManagement/Template.aspx?entity=" + Entity.Text.ToString();
            // We set a default to indicate error condition
            //todo evaluate boxes that are checked and verify total
            //create control and hand the new value to the display.           
            
            bool _CardCharged = false;

            decimal _InComingDues = (System.Convert.ToDecimal(Amount.Text.ToString()));
            if (_InComingDues <= 0)
                return;


            

               // ddlYear.SelectedValue.ToString();

            string _ccexpiry = ddlMonth.SelectedValue + "/" + ddlYear.SelectedValue.Substring(2,2);

           // string _ccexpiry = ddlMonth.SelectedValue + "/" + ddlYear.SelectedValue.Substring(ddlYear.SelectedValue.Length - 2);

            _CardCharged = PayDues_new(Entity.Text, CardType_DropDownList.Text.ToString(), 
                System.Convert.ToDecimal(Amount.Text.ToString()), Entity.Text.ToString(), 
                iMISIDText.Text, FirstName.Text.ToString() + " "
                + LastName.Text.ToString(), _ccexpiry,                 
                CCCardNumber.Text.ToString(), Address1Txt.Text.ToString(), City.Text.ToString(),
                State.Text.ToString(), Zip.Text.ToString(), _checkBoxes);
            

            if (_CardCharged)
                CompleteTransaction(false);
            else
                ProcessPaymentFailed();

           

            }
            catch (Exception _Ex)
            {
                string _msgBody = "BSCI Payment iPart Error (btnPay_Click): ";

                if (_Ex.Message != null)
                    _msgBody += "Error Message: " + _Ex.Message.ToString();

                if (_Ex.InnerException != null)
                    _msgBody += "; Error Inner Exception: " + _Ex.InnerException.ToString();

                if (_Ex.Source != null)
                    _msgBody += "; Error Source: " + _Ex.Source.ToString();

                _msgBody += "; ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; ";

                Logger.WriteLine(9, _msgBody, true);
                _BSCIPartUtils.SendErrorEmail(_msgBody);

                // show error to user..
                asilbl_ErrorMsg.Text = _msgBody;
                asilbl_ErrorMsg.Visible = true;
              
            }
            finally
            {
            }

           
            
          

          
           
        }





        private CBatch GetNextiMISBatch(Asi.iBO.SystemConfig.CCashAccount _UseThisCashAcct, string _entityCode)
        {

            try
            {
                // use for creating Batch ..
                //Asi.Security.SecurityContext.LogonByUserId("Manager");
                Asi.iBO.ContentManagement.CWebUser _webuser = Asi.iBO.ContentManagement.CWebUser.LoginByPrincipal(Asi.AppContext.CurrentPrincipal);

                // get batch number ..    
                Array batchArray;
                CBatch _UseForiMISBatch = new CBatch(_webuser);
                //CBatch _UseForiMISBatch = new CBatch(_ManagerCWebUser);


                //int iBatchCountOpen = CBatch.GetBatches(_webuser, BatchPostingStatus.Open, System.DateTime.Today, "MANAGER").Count();  //this has a count



                // see if there are any open batches today ..
                int iBatchCountOpen = 0;
                int iBatchCountPosted = 0;
                int iBatchCountReady = 0;
                int iBatchCurrentHghestBatchNumber = 0;
                int iBatchIncrement = 0;


                CBatch[] batchArray1 = CBatch.GetBatches(_webuser,BatchPostingStatus.Open, System.DateTime.Today);
                foreach (CBatch batch in batchArray1)
                {
                    if ((batch.BatchNumber.IndexOf("W" + _entityCode) != -1) && (batch.CashEntity == _entityCode))
                    { 
                        iBatchCountOpen = iBatchCountOpen + 1;
                        string thisbat = batch.BatchNumber.ToString();
                        string _lastChar = thisbat.Substring(thisbat.Length - 1);
                        if (Convert.ToInt16(_lastChar) > iBatchCurrentHghestBatchNumber)
                            iBatchCurrentHghestBatchNumber = Convert.ToInt16(_lastChar);
                    }
                }



                // no open batches today ..
                if (iBatchCountOpen == 0)
                {
                    CBatch[] batchArray2 = CBatch.GetBatches(_webuser, BatchPostingStatus.Posted, System.DateTime.Today);
                    foreach (CBatch batch in batchArray2)
                    {
                        if ((batch.BatchNumber.IndexOf("W" + _entityCode) != -1) && (batch.CashEntity == _entityCode))
                        {
                            iBatchCountPosted = iBatchCountPosted + 1;                           
                            string thisbat = batch.BatchNumber.ToString();
                            string _lastChar = thisbat.Substring(thisbat.Length - 1);
                            if (Convert.ToInt16(_lastChar) > iBatchCurrentHghestBatchNumber)
                                iBatchCurrentHghestBatchNumber = Convert.ToInt16(_lastChar);
                        }
                    }


                    CBatch[] batchArray3 = CBatch.GetBatches(_webuser, BatchPostingStatus.Ready, System.DateTime.Today);
                    foreach (CBatch batch in batchArray3)
                    {
                        if ((batch.BatchNumber.IndexOf("W" + _entityCode) != -1) && (batch.CashEntity == _entityCode))
                        { 
                            iBatchCountReady = iBatchCountReady + 1;
                            string thisbat = batch.BatchNumber.ToString();
                            string _lastChar = thisbat.Substring(thisbat.Length - 1);
                            if (Convert.ToInt16(_lastChar) > iBatchCurrentHghestBatchNumber)
                                iBatchCurrentHghestBatchNumber = Convert.ToInt16(_lastChar);
                        }
                    }


                    _UseForiMISBatch = new CBatch(_webuser);

                    
                    if (iBatchCurrentHghestBatchNumber == 0)
                        iBatchIncrement = 1;
                    else
                        iBatchIncrement = iBatchCurrentHghestBatchNumber + 1;

                    _UseForiMISBatch.BatchNumber = "W" + _entityCode + "-" + System.DateTime.Today.ToString("yyMMdd") + "-" + iBatchIncrement;

                  //  _UseForiMISBatch.CashEntity = _UseThisCashAcct.FinancialEntityCode;
                    _UseForiMISBatch.CashEntity = _entityCode;
                    _UseForiMISBatch.CashGLAccount = _UseThisCashAcct.GLCashAccount;
                    //_UseForiMISBatch.CashAccountCode = strCASH_ACCOUNT_CODE;
                    _UseForiMISBatch.CashAccountCode = _UseThisCashAcct.CashAccountCode;
                    _UseForiMISBatch.DateCreated = DateTime.Now;                    
                    _UseForiMISBatch.Description = _entityCode + " CC Site Transactions for " + DateTime.Now.ToShortDateString();

                    _UseForiMISBatch.Save();
                    return _UseForiMISBatch;
                }
                else
                {
                    // review open batches..  if (iBatchCountOpen > 0)


                    batchArray = CBatch.GetBatches(_webuser, BatchPostingStatus.Open, System.DateTime.Today);

                    bool _bolBatchFound = false;

                    // check for entity batch ..

                    foreach (CBatch batch in batchArray)
                    {
                        if ((batch.BatchNumber.IndexOf("W" + _entityCode) != -1) && (batch.CashEntity == _entityCode))
                        {
                            _bolBatchFound = true;
                            _UseForiMISBatch = batch;
                            return _UseForiMISBatch;
                        }
                    }

                   

                    if (!_bolBatchFound)
                    {
                        // create new CC batch ..
                        _UseForiMISBatch = new CBatch(_webuser);

                        _UseForiMISBatch.BatchNumber = "W" + _entityCode + "-" + System.DateTime.Today.ToString("yyMMdd") + "-9";

                       // _UseForiMISBatch.CashEntity = _UseThisCashAcct.FinancialEntityCode;
                        _UseForiMISBatch.CashEntity = _entityCode;
                        _UseForiMISBatch.CashGLAccount = _UseThisCashAcct.GLCashAccount;
                        _UseForiMISBatch.DateCreated = DateTime.Now;
                        //_UseForiMISBatch.CashAccountCode = strCASH_ACCOUNT_CODE;
                        _UseForiMISBatch.CashAccountCode = _UseThisCashAcct.CashAccountCode;
                        _UseForiMISBatch.Description = _entityCode + " CC Site Transactions for " + DateTime.Now.ToShortDateString();
                        _UseForiMISBatch.Save();
                        return _UseForiMISBatch;
                    }


                }   // end review open batches..


                // default return, should not get here ..
                // create new CC batch ..
                _UseForiMISBatch = new CBatch(_webuser);

               // _UseForiMISBatch.CashEntity = _UseThisCashAcct.FinancialEntityCode;
                _UseForiMISBatch.CashEntity = _entityCode;
                _UseForiMISBatch.CashGLAccount = _UseThisCashAcct.GLCashAccount;
                _UseForiMISBatch.DateCreated = DateTime.Now;
                //_UseForiMISBatch.CashAccountCode = strCASH_ACCOUNT_CODE;
                _UseForiMISBatch.CashAccountCode = _UseThisCashAcct.CashAccountCode;
                _UseForiMISBatch.Description = _entityCode + " Site Transactions for " + DateTime.Now.ToShortDateString();
                _UseForiMISBatch.Save();
                return _UseForiMISBatch;


            }
            catch (Exception _Ex)
            {
                string _msgBody = "BSCI Payment iPart Error (GetNextiMISBatch): ";

                if (_Ex.Message != null)
                    _msgBody += "Error Message: " + _Ex.Message.ToString();

                if (_Ex.InnerException != null)
                    _msgBody += "; Error Inner Exception: " + _Ex.InnerException.ToString();

                if (_Ex.Source != null)
                    _msgBody += "; Error Source: " + _Ex.Source.ToString();

                _msgBody += "; ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; ";

                Logger.WriteLine(9, _msgBody, true);
                _BSCIPartUtils.SendErrorEmail(_msgBody);

                // show error to user..
                asilbl_ErrorMsg.Text = _msgBody;
                asilbl_ErrorMsg.Visible = true;



                return null;
            }
            finally
            {
            }


        }





        public bool PayDues_new(String mEntity, String mCashAccountCode, Decimal mAmount, String mTransactionComment1,
            String mTransactionComment2, String mCreditDebitCardHoldersName, String mCreditCardExpiration,
            String mCreditCardNumber, String mAddress1, String mCity, String mStateProvince, String mPostalCode, ArrayList _checkBoxes)
        {
            int i = 0;
            bool bSuccess = false;

            try
            {
                bool _LogCheck = CheckPaymentLogging();

                if (_LogCheck)
                {
                    // have a pending payment, batch NOT posted...
                    pan_finish.Visible = true;
                    ltl_DoNotAllowPayment.Visible = true;

                    pan_main.Visible = false;
                }



               // DateTime dateValue;
               
                //dateValue = DateTime.Parse(mCreditCardExpiration);
               // mCreditCardExpiration = dateValue.ToString("MM/yy");
               
                // Create a CWebUser object. To process dues, you can’t use any other type of IiMISUser (such as CStaffUser or CContactUser), even though the 
                // function which actually processes the dues (CSubscription.PayDues) just requires an IiMISUser in its signature. If you pass anything other than a CWebUser to that function, you’ll get an error.
                CWebUser _WebUser = CWebUser.LoginByPrincipal(Asi.AppContext.CurrentPrincipal);

                //Asi.iBO.IiMISUser _iMISUser = _WebUser;                

                // set-up iBO..
                _iMISUser.ThrowExceptionOnError = true;
                _iMISUser.ThrowExceptionOnWarning = false;
                Asi.iBO.ContactManagement.CContact _CContact = new Asi.iBO.ContactManagement.CContact(_WebUser, clsSessionHandler.iMIS_LoggedIn_UserID);


                //Asi.iBO.ContactManagement.CContactUser coImisUser = Asi.iBO.ContactManagement.CContactUser.LoginByWebLogin("manager");
                Asi.iBO.Financials.CPayment cpay = new Asi.iBO.Financials.CPayment(_WebUser);

                Asi.iBO.SystemConfig.CCashAccount _iMISCashAcct;
                _iMISCashAcct = iboAdmin.ReferenceData.GetCashAccount(mCashAccountCode);
                _gtway_iMISCashAcctUsed = _iMISCashAcct.CashAccountCode.ToString();
                _gtway_iMISCashAcctUsedDescription = _iMISCashAcct.Description;

                // get batch to use for transaction..
                CBatch _UseForiMISBatch = GetNextiMISBatch(_iMISCashAcct, mEntity);

                // set-up payment object..
                cpay.TransactionComment1 = _CContact.FullName + "   " + mTransactionComment1;
                cpay.TransactionComment2 = "ID " + clsSessionHandler.iMIS_LoggedIn_UserID + " Paid  " + mEntity + "_" + System.DateTime.Today.ToString("ddMMyy");
                cpay.PaymentType = Asi.iBO.Financials.EnumPaymentType.CreditCard;
                //cpay.CashAccountCode = mCashAccountCode;
                cpay.CashAccountCode = _iMISCashAcct.CashAccountCode;

                cpay.CreditCardExpiration = mCreditCardExpiration;
                cpay.CreditDebitCardHoldersName = mCreditDebitCardHoldersName;
                cpay.CreditCardNumber = mCreditCardNumber;

                cpay.Amount = mAmount;                

                if (cpay.Validate())
                {
                    // send payment to gateway, do handshake ..

                    Asi.iBO.ContactManagement.CAddressBasic TheContactAddress = new Asi.iBO.ContactManagement.CAddressBasic(_iMISUser);
                    TheContactAddress.Address1 = mAddress1;
                    TheContactAddress.City = mCity;
                    TheContactAddress.StateProvince = mStateProvince;
                    TheContactAddress.PostalCode = mPostalCode;
                    //TheContactAddress.Country = mCountry;

                    Asi.iBO.ContactManagement.CAddressBasic coAddress = TheContactAddress;

                    Asi.iBO.Commerce.PaymentGatewayResponse cPayRes = cpay.ProcessPayment(Asi.iBO.Commerce.TransactionType.Authorization, coAddress);

                    if (cPayRes.IsSuccess)
                    {
                        _gtway_AuthorizationCode = cPayRes.AuthorizationCode;
                        _gtway_CardProcessingStatus = cPayRes.CardProcessingStatus;
                        _gtway_ReferenceID = cPayRes.ReferenceId;
                        _gtway_ResponseMessage = cPayRes.ResponseMessage;
                        _gtway_Result = cPayRes.Result;
                        _gtway_PayAmount = cpay.Amount;

                        //  write details of payment to logging table ..
                        LogPaymentDetails(cpay, _UseForiMISBatch.BatchNumber.ToString(), true, mEntity);

                   

                        // completes rest of data processing in iMIS ..

                        // Create a CWebUser object. To process dues, you can’t use any other type of IiMISUser (such as CStaffUser or CContactUser), even though the 
                        // function which actually processes the dues (CSubscription.PayDues) just requires an IiMISUser in its signature. If you pass anything other than a CWebUser to that function, you’ll get an error.
                        //CWebUser WebUser = CWebUser.LoginByPrincipal(Asi.AppContext.CurrentPrincipal);

                        bool _iBOTransOK = Complete_iBO_Transaction(_WebUser, cpay, _UseForiMISBatch, mEntity);
                        if (!_iBOTransOK)
                        {
                            // false returned by routine ..
                            string strErrorDesc = "An error has occurred in the BSCIDuesPaymentsPart_Display, ProcessSaleiBO, the Complete_iBO_Transaction() method returned false.  The user was able to process a payment, but an error ocurred writing the financial transaction, the user received the error page but the data needs to be reviewed and the member contacted. The successful transaction has been logged.";
                            Logger.WriteLine(9, "ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; " + strErrorDesc, true);
                            _BSCIPartUtils.SendErrorEmail("ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; " + strErrorDesc);  
                            return false;
                        }

                        // payment completed ..
                        bSuccess = true;
                        return bSuccess;
                    }
                    else
                    {
                        // payment failed ..
                        _gtway_ResponseMessage = cPayRes.ResponseMessage;
                        _gtway_Result = cPayRes.Result;                        

                        //  write details of payment to logging table ..
                        LogPaymentDetails(cpay, _UseForiMISBatch.BatchNumber.ToString(), false, mEntity);

                        // return false as payment is not successful ..                       
                        return false;
                    }
               
                    
                }
                else
                {
                    // fails iBO Payment Validation..
                    if ( cpay.Errors.PrimaryErrorNumber.ToString() == "12")
                    {
                        _gtway_Result = "12";
                        return false;
                    }

                      
                    string strErrorDesc = "payDues - fails iBO Payment Validation..: The error is: ";
                    strErrorDesc = strErrorDesc + cpay.Errors.PrimaryErrorMessage.ToString();
                   
                    Logger.WriteLine(9, "ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; " + strErrorDesc, true);
                    _BSCIPartUtils.SendErrorEmail("ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; " + strErrorDesc);

                    return false;   
                }
                    

                   
            }
            catch (Exception _Ex)
            {
                string _msgBody = "BSCI Payment iPart Error (payDues_New): ";

                if (_Ex.Message != null)
                    _msgBody += "Error Message: " + _Ex.Message.ToString();

                if (_Ex.InnerException != null)
                    _msgBody += "; Error Inner Exception: " + _Ex.InnerException.ToString();

                if (_Ex.Source != null)
                    _msgBody += "; Error Source: " + _Ex.Source.ToString();

                _msgBody += "; ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; ";

                Logger.WriteLine(9, _msgBody, true);
                _BSCIPartUtils.SendErrorEmail(_msgBody);

                // show error to user..
                //asilbl_ErrorMsg.Text = _msgBody;
                //asilbl_ErrorMsg.Visible = true;

                return false;
            }


        }




        /// <summary>
        /// called by the PayNow method ..  
        /// final steps (display, routing  all data updates are complete by now..
        /// </summary>
        protected void CompleteTransaction(bool _SpecialHandling)
        {
            try
            {
                CleanUpForm(false);

                // display success panel ...
                // to display via style ..
                //pan_finish.Style.Remove("display");
               // pan_finish.Style.Add("display", "inline");
                pan_finish.Visible = true;
                ltl_DoNotAllowPayment.Visible = false;

                // to hide via style ..
               // pan_main.Style.Add("display", "none");

                pan_main.Visible = false;
                // send confirmation email...
                string _msgBody = string.Empty;

               // var dict = new Dictionary<string, string>();
               // dict = clsSessionHandler.DictEmailDetail;
                
               // loop through Dictionary and build display message...
               //foreach (var item in dict) 
               //{ 
               //    item.Value.ToString(); 
               //}

               //foreach (string key in dict.Keys)
               //{
               //string valAsString = dict[key].ToString();
               //       //Logger.WriteLine("IQAColumnList Dictionary: " + key + " " + valAsString);
               //}


                if (_SpecialHandling)
                        _msgBody = "<p><strong>Sorry</strong>, we had a problem applying your payment.  Your credit card <strong>WAS</strong> charged.  Staff has been notified of the error and will contact you regarding the processing of your payment.  Please do not attempt to pay again until you hear from us.  We apologize for the inconvenience.</p>";

                _msgBody += "<p>&nbsp;&nbsp;<span style=''text-decoration: underline''><b>Payment Details</b></span></p><table width=''50%''>"
                 + "<tr><td style=''width:2%;''>&nbsp;</td><td style=''width:63%;''>ID:</td><td style=''width:5%;''>&nbsp;</td><td style=''width:20%;text-align:right''> " + clsSessionHandler.iMIS_LoggedIn_UserID + " </td><td style=''width:10%;''>&nbsp;</td></tr>"
                 + "<tr><td style=''width:2%;''>&nbsp;</td><td style=''width:63%;''>Name:</td><td style=''width:5%;''>&nbsp;</td><td style=''width:20%;text-align:right''> " + FirstName.Text + " " + LastName.Text + " </td><td style=''width:10%;''>&nbsp;</td></tr>"
                 + "<tr><td style=''width:2%;''>&nbsp;</td><td style=''width:63%;''>Date:</td><td style=''width:5%;''>&nbsp;</td><td style=''width:20%;text-align:right''> " + DateTime.Now.ToShortDateString() + " </td><td style=''width:10%;''>&nbsp;</td></tr>"
                 + " <tr><td style=''width:2%;''>&nbsp;</td><td style=''width:63%;''>Total Amount Charged:</td><td style=''width:5%;''>&nbsp;</td><td style=''width:20%;text-align:right''>  $" + _gtway_PayAmount.ToString("N2") + " </td><td style=''width:10%;''>&nbsp;</td></tr>"
                + "<tr><td style=''width:2%;''>&nbsp;</td><td style=''width:63%;''>Card Type:</td><td style=''width:5%;''>&nbsp;</td><td style=''width:20%;text-align:right''> " + _gtway_iMISCashAcctUsedDescription + " </td><td style=''width:10%;''>&nbsp;</td></tr>"
                + "<tr><td style=''width:2%;''>&nbsp;</td><td style=''width:63%;''>Gateway Transaction Number:</td><td style=''width:5%;''>&nbsp;</td><td style=''width:20%;text-align:right''> " + _gtway_ReferenceID + " </td><td style=''width:10%;''>&nbsp;</td></tr>"
                + "</table>"
                + "<br /><br /><p><span>Thank You for your payment.</span></p><br /><br />";



                if (txtEmailAddress.Text != "")
                SendConfirmationEmail(_msgBody);

                ltl_finaldisplay.Visible = true;
                ltl_finaldisplay.Text = _msgBody;


                

            }
            catch (Exception _Ex)
            {
                string _msgBody = "BSCI Payment iPart Error (Complete_Transaction): ";

                if (_Ex.Message != null)
                    _msgBody += "Error Message: " + _Ex.Message.ToString();

                if (_Ex.InnerException != null)
                    _msgBody += "; Error Inner Exception: " + _Ex.InnerException.ToString();

                if (_Ex.Source != null)
                    _msgBody += "; Error Source: " + _Ex.Source.ToString();

                _msgBody += "; ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; ";

                Logger.WriteLine(9, _msgBody, true);
                _BSCIPartUtils.SendErrorEmail(_msgBody);

                // show error to user..
                asilbl_ErrorMsg.Text = _msgBody;
                asilbl_ErrorMsg.Visible = true;

            }
            finally
            {
            }
        }






        /// <summary>
        /// called by the PayNow method ..
        ///  
        /// </summary>
        protected void ProcessPaymentFailed()
        {
            try
            {
                string _ErrorMsgDisplayedToUser = string.Empty;

                //  see if we handle gateway error and allow re-try of payment ..
                bool _HandleError_AllowPaymentAgain = false;

                string _ResultCodesToHandle = "";

               
                   
                        // PayPal gateway cash accounts.. DISCOVER AND MASTER CARD ..
                        if (_gtway_Result != "0")
                        {
                            // payment failed, see if we allow re-payment or not..

                            // check handled gateway error codes in CMS config property ...      
                            _ResultCodesToHandle = HandledGatewayErrorCodes;

                            string[] workthroughCodes = _ResultCodesToHandle.Split(',');
                            foreach (string resultcode in workthroughCodes)
                            {
                                if (resultcode == _gtway_Result)
                                {
                                    // 12:  declined ..
                                    if (_gtway_Result == "12")
                                    {
                                        _ErrorMsgDisplayedToUser = "There was a problem with the transaction, please re-enter the transaction information and press the 'Submit' button again:  charge was declined.<br /><br />";
                                    }

                                    // 23:  invalid account number ..
                                    if (_gtway_Result == "23")
                                    {
                                        _ErrorMsgDisplayedToUser = "There was a problem with the transaction, please re-enter the transaction information and press the 'Submit' button again:  invalid card number.<br /><br />";
                                    }

                                    // 24:  invalid expiration date ..
                                    if (_gtway_Result == "24")
                                    {
                                        _ErrorMsgDisplayedToUser = "There was a problem with the transaction, please re-enter the transaction information and press the 'Submit' button again:  invalid expiration date.<br /><br />";
                                    }
                                    // if we have a value added to web.config but no code added here..
                                    if (_ErrorMsgDisplayedToUser == String.Empty)
                                        _ErrorMsgDisplayedToUser = "There was a problem with the transaction, please re-enter the transaction information and press the 'Submit' button again.<br /><br />";

                                    _HandleError_AllowPaymentAgain = true;
                                }
                            }

                            if (_HandleError_AllowPaymentAgain)
                            {
                                // display error msg, enable controls..
                                CleanUpForm(true);

                                //asilbl_ErrorMsg.Text = "<br /><br />There was a problem with the transaction please re-enter the transaction information and try again: " + _gtway_ResponseMessage;
                                asilbl_ErrorMsg.Text = _ErrorMsgDisplayedToUser;
                                asilbl_ErrorMsg.Visible = true;

                                // display note to user as validation failed ..
                                RadWindowManager1.RadAlert("Please review your payment details, there is a problem with the data as submitted.", 330, 100, "Check Payment Details", null);
                            }
                            else
                            {
                                // don't display error, send email to staff, display error message ..
                                CleanUpForm(false);

                                string strErrorDesc = "For ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; BSCIPayPart_Display:  ProcessPaymentFailed():  An un-handled CC gateway response code has been received for ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + ".  The result code is: " + _gtway_Result + ". The failed transaction has been logged. The user is not able to process a payment and received the error page. The response message is: " + _gtway_ResponseMessage;

                                Logger.WriteLine(9, strErrorDesc, true);
                                _BSCIPartUtils.SendErrorEmail(strErrorDesc);
                                string _display_copy = "Sorry, we received a gateway response code indicating there was an error and we were not able to process your payment.  Please try again.  We apologize for the inconvenience.";

                                // show error to user..
                                asilbl_ErrorMsg.Text = _display_copy;
                                asilbl_ErrorMsg.Visible = true;    
                            }
                        }
                        else
                        {
                            // result code was 0, payment was successful but a downstream error occurred..
                            CleanUpForm(false);

                            string strErrorDesc = "For ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; BSCIPayPart_Display:  ProcessPaymentFailed()-CC:  The result code is: " + _gtway_Result + ". The user was able to process a payment, but an error ocurred writing the financial transaction, the user received the error page but the data needs to be reviewed and the member contacted. The successful transaction has been logged.";

                            Logger.WriteLine(9, strErrorDesc, true);
                            _BSCIPartUtils.SendErrorEmail(strErrorDesc);

                            // show error to user..
                            //string _display_copy = "Sorry, we had a problem applying your payment.  Your credit card WAS charged.  Staff has been notified of the error and will contact you regarding the processing of your payment.  Please do not attempt to pay again until you hear from us.  We apologize for the inconvenience.";
                            //asilbl_ErrorMsg.Text = _display_copy;
                            //asilbl_ErrorMsg.Visible = true;        
                        
                            // we no longer do the above...we now show user their transaction details but display special messaging and special alert emails are sent to staff..
                            CompleteTransaction(true);                           
                        }
                  
                    



                

            }
            catch (Exception _Ex)
            {
                string _msgBody = "BSCI Payment iPart Error (ProcessPaymentFailed): ";

                if (_Ex.Message != null)
                    _msgBody += "Error Message: " + _Ex.Message.ToString();

                if (_Ex.InnerException != null)
                    _msgBody += "; Error Inner Exception: " + _Ex.InnerException.ToString();

                if (_Ex.Source != null)
                    _msgBody += "; Error Source: " + _Ex.Source.ToString();

                _msgBody += "; ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; ";

                Logger.WriteLine(9, _msgBody, true);
                _BSCIPartUtils.SendErrorEmail(_msgBody);

                // show error to user..
                asilbl_ErrorMsg.Text = _msgBody;
                asilbl_ErrorMsg.Visible = true;               

                
            }
            finally
            {
            }


        }



        /// <summary>
        /// re-sets all controls on form..
        /// </summary>
        protected void CleanUpForm(bool _allowrepay)
        {
            if (_allowrepay)
            {
                btnPay.Enabled = true;

                _gtway_AuthorizationCode = "";
                _gtway_CardProcessingStatus = 0;
                _gtway_ReferenceID = "";
                _gtway_ResponseMessage = "";
                _gtway_Result = "";
                _gtway_TransID = "";

            }
            else
            {
                CCCardNumber.Text = "";
                Amount.Text = "0";
                btnPay.Enabled = false;

                clsSessionHandler.SHrunningDuesBalance = 0;
                clsSessionHandler.TotalFeesFound = 0;


            }



        }








        /// <summary>
        /// called by the ProcessSaleiBO method after call to payment.ProcessPayment() ..
        /// inserts details into sql table:  BSCI_PayPartLogging
        /// </summary>
        protected void LogPaymentDetails(CPayment _completedpayment, string _usethisbatch, bool _IsSuccess, string _EC)
        {
            try
            {

                string sqlInsertTrans = "INSERT INTO BSCI_PayPartLogging( ID, PAYMENT_AMOUNT, CONVFEE_AMOUNT, CASH_ACCOUNT_CODE, CC_NUMBER, CSC, CC_EXPIRATION, ACH_ROUTING_NUMBER, ACH_ACCOUNT_NUMBER, NAME_USED, AUTHCODE, CARD_PROCESSING_STATUS, IS_SUCCESS, REFERENCE_ID, RESPONSE_MESSAGE, RESULT, WHEN_PAYMENT_MADE, BATCH_NUMBER) VALUES ( @ID, @PAYMENT_AMOUNT, @CONVFEE_AMOUNT, @CASH_ACCOUNT_CODE, @CC_NUMBER, @CSC, @CC_EXPIRATION, @ACH_ROUTING_NUMBER, @ACH_ACCOUNT_NUMBER, @NAME_USED, @AUTHCODE, @CARD_PROCESSING_STATUS, @IS_SUCCESS, @REFERENCE_ID, @RESPONSE_MESSAGE, @RESULT, @WHEN_PAYMENT_MADE, @BATCH_NUMBER)";

                Asi.Data.DataParameter[] paramColl = new Asi.Data.DataParameter[18];

                paramColl[0] = new Asi.Data.DataParameter();
                paramColl[0].SqlDbType = System.Data.SqlDbType.VarChar;
                paramColl[0].ParameterName = "@ID";
                paramColl[0].Value = clsSessionHandler.iMIS_LoggedIn_UserID;

                paramColl[1] = new Asi.Data.DataParameter();
                paramColl[1].SqlDbType = System.Data.SqlDbType.Money;
                paramColl[1].ParameterName = "@PAYMENT_AMOUNT";
                paramColl[1].Value = _completedpayment.Amount;

                paramColl[2] = new Asi.Data.DataParameter();
                paramColl[2].SqlDbType = System.Data.SqlDbType.Money;
                paramColl[2].ParameterName = "@CONVFEE_AMOUNT";
                paramColl[2].Value = 0;

                paramColl[3] = new Asi.Data.DataParameter();
                paramColl[3].SqlDbType = System.Data.SqlDbType.VarChar;
                paramColl[3].ParameterName = "@CASH_ACCOUNT_CODE";
                paramColl[3].Value = _completedpayment.CashAccountCode;

                paramColl[4] = new Asi.Data.DataParameter();
                paramColl[4].SqlDbType = System.Data.SqlDbType.VarChar;
                paramColl[4].ParameterName = "@CC_NUMBER";
                paramColl[4].Value = _completedpayment.CreditDebitCardNumberMasked;

                paramColl[5] = new Asi.Data.DataParameter();
                paramColl[5].SqlDbType = System.Data.SqlDbType.VarChar;
                paramColl[5].ParameterName = "@CSC";
                paramColl[5].Value = _completedpayment.CreditCardSecurityCode.ToString();

                paramColl[6] = new Asi.Data.DataParameter();
                paramColl[6].SqlDbType = System.Data.SqlDbType.VarChar;
                paramColl[6].ParameterName = "@CC_EXPIRATION";
                paramColl[6].Value = _completedpayment.CreditCardExpiration.ToString();

                paramColl[7] = new Asi.Data.DataParameter();
                paramColl[7].SqlDbType = System.Data.SqlDbType.VarChar;
                paramColl[7].ParameterName = "@ACH_ROUTING_NUMBER";
                paramColl[7].Value = "n/a";

                paramColl[8] = new Asi.Data.DataParameter();
                paramColl[8].SqlDbType = System.Data.SqlDbType.VarChar;
                paramColl[8].ParameterName = "@ACH_ACCOUNT_NUMBER";
                paramColl[8].Value = _EC.ToString();

                paramColl[9] = new Asi.Data.DataParameter();
                paramColl[9].SqlDbType = System.Data.SqlDbType.VarChar;
                paramColl[9].ParameterName = "@NAME_USED";
                paramColl[9].Value = _completedpayment.CreditDebitCardHoldersName.ToString();

                paramColl[10] = new Asi.Data.DataParameter();
                paramColl[10].SqlDbType = System.Data.SqlDbType.VarChar;
                paramColl[10].ParameterName = "@AUTHCODE";
                if (_IsSuccess)
                    paramColl[10].Value = _gtway_AuthorizationCode;
                else
                    paramColl[10].Value = "n/a";

                paramColl[11] = new Asi.Data.DataParameter();
                paramColl[11].SqlDbType = System.Data.SqlDbType.VarChar;
                paramColl[11].ParameterName = "@CARD_PROCESSING_STATUS";
                paramColl[11].Value = _gtway_CardProcessingStatus;

                paramColl[12] = new Asi.Data.DataParameter();
                paramColl[12].SqlDbType = System.Data.SqlDbType.Bit;
                paramColl[12].ParameterName = "@IS_SUCCESS";
                paramColl[12].Value = _IsSuccess;

                paramColl[13] = new Asi.Data.DataParameter();
                paramColl[13].SqlDbType = System.Data.SqlDbType.VarChar;
                paramColl[13].ParameterName = "@REFERENCE_ID";
                if (_IsSuccess)
                    paramColl[13].Value = _gtway_ReferenceID;
                else
                    paramColl[13].Value = "n/a";

                paramColl[14] = new Asi.Data.DataParameter();
                paramColl[14].SqlDbType = System.Data.SqlDbType.VarChar;
                paramColl[14].ParameterName = "@RESPONSE_MESSAGE";
                paramColl[14].Value = _gtway_ResponseMessage;

                paramColl[15] = new Asi.Data.DataParameter();
                paramColl[15].SqlDbType = System.Data.SqlDbType.VarChar;
                paramColl[15].ParameterName = "@RESULT";
                paramColl[15].Value = _gtway_Result;

                paramColl[16] = new Asi.Data.DataParameter();
                paramColl[16].SqlDbType = System.Data.SqlDbType.DateTime;
                paramColl[16].ParameterName = "@WHEN_PAYMENT_MADE";
                paramColl[16].Value = DateTime.Now;

                paramColl[17] = new Asi.Data.DataParameter();
                paramColl[17].SqlDbType = System.Data.SqlDbType.VarChar;
                paramColl[17].ParameterName = "@BATCH_NUMBER";
                paramColl[17].Value = _usethisbatch;


                using (Asi.Data.DataServer server = new Asi.Data.DataServer())
                {
                    System.Data.DataTable allData = new System.Data.DataTable();

                    System.Data.DataSet ds = server.ExecuteDataSet(System.Data.CommandType.Text, sqlInsertTrans, paramColl);

                    //allData = ds.Tables[0];
                }

            }
            catch (Exception _Ex)
            {
                string _msgBody = "BSCI Payment iPart Error (LogPaymentDetails): ";

                if (_Ex.Message != null)
                    _msgBody += "Error Message: " + _Ex.Message.ToString();

                if (_Ex.InnerException != null)
                    _msgBody += "; Error Inner Exception: " + _Ex.InnerException.ToString();

                if (_Ex.Source != null)
                    _msgBody += "; Error Source: " + _Ex.Source.ToString();

                _msgBody += "; ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; ";

                Logger.WriteLine(9, _msgBody, true);
                _BSCIPartUtils.SendErrorEmail(_msgBody);

                // show error to user..
                asilbl_ErrorMsg.Text = _msgBody;
                asilbl_ErrorMsg.Visible = true;






            }
            finally
            {
            }


        }






        /// <summary>
        /// called by the ProcessSaleiBO method after call to payment.ProcessPayment() if succesful..
        /// sets-up CC convienience fee products, adjusts fee records for payment, and runs iBO CSubscription.PayDues() method ..
        /// </summary>
        private bool Complete_iBO_Transaction(CWebUser _webuser, CPayment _completedpayment, CBatch _usethisbatch, string _enityCodeForPayment)
        {
            try
            {

                //Asi.iBO.IiMISUser ff = _webuser;
                _iMISUser.ThrowExceptionOnError = true;
                _iMISUser.ThrowExceptionOnWarning = false;
                Asi.iBO.ContactManagement.CContact ccon = new Asi.iBO.ContactManagement.CContact(_webuser, clsSessionHandler.iMIS_LoggedIn_UserID);


              

                int i = 0;
                // loop to count records to pay

                foreach (CSubscription subscription in ccon.Subscriptions)
                {
                    if ((subscription.DuesProduct.FinancialEntityCode == _enityCodeForPayment) && (subscription.StatusCode == "A") && (subscription.Balance > 0))                        
                    {
                       
                        if ((subscription.ProductTypeCode == "DUES") && (subscription.CopiesPaid == 0))
                        {
                            i = i + 1;                            
                        }
                        if ((subscription.ProductTypeCode == "VOL") && (subscription.CopiesPaid == 0))
                        {
                            foreach (CheckBox mCheckBox in _checkBoxes)
                            {                                
                                if (mCheckBox.Checked == true && mCheckBox.ID == "ckb_" + subscription.ProductCode.ToString())
                                {
                                    i = i + 1;                                    
                                }
                            }
                        }
                    }

                }   // end 1st for loop

                //ccon.Save();


                // loop to load colleciton to throw at PayDues method...
                CSubscription[] substopay = new CSubscription[i];

                // use later for conf. email  if need to list products..  NOT USING JUST NOW BUT STILL OADING WITH DATA...
                var dict = new Dictionary<string, string>();

                i = 0;

                foreach (CSubscription subscription in ccon.Subscriptions)
                {
                    if ((subscription.DuesProduct.FinancialEntityCode == _enityCodeForPayment) && (subscription.StatusCode == "A") && (subscription.Balance > 0))
                    {
                        if ((subscription.ProductTypeCode == "DUES") && (subscription.CopiesPaid == 0))
                        {
                            i = i + 1;                                  
                            if (subscription.BillThruDate == null)
                            {
                                subscription.BillThruDate = Convert.ToDateTime("12/31/" + DateTime.Now.AddYears(i).Year.ToString());
                            }
                            if (subscription.BillBeginDate == null)
                            {
                                subscription.BillBeginDate = Convert.ToDateTime("01/01/" + DateTime.Now.AddYears(i).Year.ToString());
                            }

                            //subscription.CopiesPaid = 1;
                            subscription.Validate();

                            dict.Add(subscription.ProductCode, subscription.DuesProduct.Title.ToString() + " - " + subscription.Balance.ToString());
                            substopay[i -1] = subscription;
                        }

                        if ((subscription.ProductTypeCode == "VOL") && (subscription.CopiesPaid == 0))
                        {
                            foreach (CheckBox mCheckBox in _checkBoxes)
                            {
                                if (mCheckBox.Checked == false && mCheckBox.ID == "ckb_" + subscription.ProductCode.ToString())
                                {
                                    subscription.AmountPaid = 0;
                                    if (subscription.BillThruDate == null)
                                    {
                                        subscription.BillThruDate = Convert.ToDateTime("12/31/" + DateTime.Now.AddYears(i).Year.ToString());
                                    }
                                    if (subscription.BillBeginDate == null)
                                    {
                                        subscription.BillBeginDate = Convert.ToDateTime("01/01/" + DateTime.Now.AddYears(i).Year.ToString());
                                    }
                                    subscription.Validate();
                                }
                                if (mCheckBox.Checked == true && mCheckBox.ID == "ckb_" + subscription.ProductCode.ToString())
                                {
                                    i = i + 1;                                       
                                    if (subscription.BillThruDate == null)
                                    {
                                        subscription.BillThruDate = Convert.ToDateTime("12/31/" + DateTime.Now.AddYears(i).Year.ToString());
                                    }
                                    if (subscription.BillBeginDate == null)
                                    {
                                        subscription.BillBeginDate = Convert.ToDateTime("01/01/" + DateTime.Now.AddYears(i).Year.ToString());
                                    }

                                   // subscription.CopiesPaid = 1;
                                    subscription.Validate();
                                    dict.Add(subscription.ProductCode, subscription.DuesProduct.Title.ToString() + " - " + subscription.Balance.ToString());
                                    substopay[i -1] = subscription;
                                }

                            }
                        }
                    }


                }   // end 2nd for loop


                Asi.iBO.Errors.CErrors ASIErrColl = null;

                bool blnCheckiBOData = ccon.Validate();
                if (blnCheckiBOData)
                {
                    ccon.Save();

                    // use later for conf. email  if need to list products..
                    clsSessionHandler.DictEmailDetail = dict;
                }
                else
                {
                    ASIErrColl = ccon.Errors;
                    string strErrorDesc = "An iBO error has occurred in the Complete_iBO_Transaction method for ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + " - end 2nd fee loop; The error is: ";
                    if (ASIErrColl.ErrorCount > 0)
                    {
                        strErrorDesc = strErrorDesc + ASIErrColl.PrimaryErrorMessage.ToString();
                        //string iii = ASIErrColl.GetError(0).Message.ToString();
                    }

                    Logger.WriteLine(9, strErrorDesc, true);
                    _BSCIPartUtils.SendErrorEmail(strErrorDesc);
                }







                // 3rd loop, set amt paid..
                foreach (CSubscription sub3 in ccon.Subscriptions)
                {
                    if (sub3.DuesProduct.FinancialEntityCode == _enityCodeForPayment)
                    {
                        if ((sub3.ProductTypeCode == "DUES") && (sub3.CopiesPaid == 0))
                        {                           
                            sub3.AmountPaid = sub3.Balance;
                            sub3.Validate();
                        }

                        if ((sub3.ProductTypeCode == "VOL") && (sub3.CopiesPaid == 0))
                        {
                            foreach (CheckBox mCheckBox in _checkBoxes)
                            {
                                if (mCheckBox.Checked == true && mCheckBox.ID == "ckb_" + sub3.ProductCode.ToString())
                                {                                    
                                    sub3.AmountPaid = sub3.Balance;
                                    sub3.Validate();
                                }
                            }
                        }
                    }


                }   // end 3rd for loop

                //blnCheckiBOData = ccon.Validate();
                //if (blnCheckiBOData)
                //{
                //    ccon.Save();
                //}
                //else
                //{
                //    ASIErrColl = ccon.Errors;
                //    string strErrorDesc = "An iBO error has occurred in the Complete_iBO_Transaction method for ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + " - end 3rd fee loop; The error is: ";
                //    if (ASIErrColl.ErrorCount > 0)
                //    {
                //        strErrorDesc = strErrorDesc + ASIErrColl.PrimaryErrorMessage.ToString();
                //        //string iii = ASIErrColl.GetError(0).Message.ToString();
                //    }

                //    Logger.WriteLine(9, strErrorDesc, true);
                //    _BSCIPartUtils.SendErrorEmail(strErrorDesc);
                //}








                // this is main iBO method to pay dues ..
                ASIErrColl = CSubscription.PayDues(_webuser, substopay, ref _completedpayment, _usethisbatch);

                if (ASIErrColl.ErrorCount > 0)
                {
                    string strErrorDesc = "An iBO error has occurred in the BSCI PayPart_Display, Complete_iBO_Transaction() method. The error is: ";
                    strErrorDesc = strErrorDesc + ASIErrColl.PrimaryErrorMessage.ToString();

                    Logger.WriteLine(9, "ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; " + strErrorDesc, true);
                    _BSCIPartUtils.SendErrorEmail("ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; " + strErrorDesc);                                              
                    return false;
                }



                // 4th loop, set amt paid..
                foreach (CSubscription sub3 in ccon.Subscriptions)
                {
                    if (sub3.DuesProduct.FinancialEntityCode == _enityCodeForPayment)
                    {
                        if ((sub3.ProductTypeCode == "DUES") && (sub3.CopiesPaid == 0))
                        {
                            sub3.CopiesPaid = 1;
                            sub3.AmountPaid = 0;
                            sub3.Validate();
                        }

                        if ((sub3.ProductTypeCode == "VOL") && (sub3.CopiesPaid == 0))
                        {
                            foreach (CheckBox mCheckBox in _checkBoxes)
                            {
                                if (mCheckBox.Checked == true && mCheckBox.ID == "ckb_" + sub3.ProductCode.ToString())
                                {
                                    sub3.CopiesPaid = 1;
                                    sub3.AmountPaid = 0;
                                    sub3.Validate();
                                }
                            }
                        }
                    }


                }   // end 4th for loop

                blnCheckiBOData = ccon.Validate();
                if (blnCheckiBOData)
                {
                    ccon.Save();
                }
                else
                {
                    ASIErrColl = ccon.Errors;
                    string strErrorDesc = "An iBO error has occurred in the Complete_iBO_Transaction method for ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + " - end 4th fee loop; The error is: ";
                    if (ASIErrColl.ErrorCount > 0)
                    {
                        strErrorDesc = strErrorDesc + ASIErrColl.PrimaryErrorMessage.ToString();
                        //string iii = ASIErrColl.GetError(0).Message.ToString();
                    }

                    Logger.WriteLine(9, strErrorDesc, true);
                    _BSCIPartUtils.SendErrorEmail(strErrorDesc);
                }







                // RUN SQL TO CLEAN-UP STUFF..
                object retvalueobj = null;
                string _sql_update = "update Trans set BT_ID = ST_ID WHERE BT_ID = '' and TRANSACTION_DATE < (dateadd(dd,2,getdate())) AND ST_ID = '" + clsSessionHandler.iMIS_LoggedIn_UserID + "'"; using (Asi.Data.DataServer server = new Asi.Data.DataServer())
                {
                    retvalueobj = server.ExecuteScalar(System.Data.CommandType.Text, _sql_update);
                }

                if (retvalueobj == null)
                {
                    string we_are_okay_here = "esed";
                }
                else
                {
                    Logger.WriteLine(9, "SQL UPDATE error;", true);
                    //_ARDCSiteUtils.SendEmailError(SessionHandlerARDCNCOABusiness.iMIS_LoggedIn_UserID, "NCOABusiness_Display", "sp_bsci_NCOA_AffirmUpdate: business affirm error;");

                }



               
                return true;

            }
            catch (Exception _Ex)
            {
                string _msgBody = "BSCI Payment iPart Error (Complete_iBO_Transaction): ";

                if (_Ex.Message != null)
                    _msgBody += "Error Message: " + _Ex.Message.ToString();

                if (_Ex.InnerException != null)
                    _msgBody += "; Error Inner Exception: " + _Ex.InnerException.ToString();

                if (_Ex.Source != null)
                    _msgBody += "; Error Source: " + _Ex.Source.ToString();

                _msgBody += "; ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; ";

                Logger.WriteLine(9, _msgBody, true);
                _BSCIPartUtils.SendErrorEmail(_msgBody);
               
                //Response.Redirect("regsiteerror.aspx?errhandletype=1", false);

                return false;
            }
            finally
            {
            }



        }


        /// <summary>
        /// called by the ProcessSaleiBO method after call to payment.ProcessPayment() if succesful..
        /// sets-up CC convienience fee products, adjusts fee records for payment, and runs iBO CSubscription.PayDues() method ..
        /// </summary>
        private bool CheckPaymentLogging()
        {

            string sql = string.Empty;
            try
            {



                //DateTime dt = DateTime.Now;
                // Sets the CurrentCulture property to U.S. English.
                //Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

                CultureInfo ci;
                ci = new CultureInfo("en-US");

                //// 2nd review ... check payment logging for recent transactions...            
                 sql = "select count(ID) FROM BSCI_PayPartLogging where BSCI_PayPartLogging.ID = '" + clsSessionHandler.iMIS_LoggedIn_UserID + "' AND BSCI_PayPartLogging.IS_SUCCESS = 1 and datediff(d, WHEN_PAYMENT_MADE, getdate()) < 3 AND " + clsSessionHandler.SHrunningDuesBalance.ToString("G", ci) + " >= BSCI_PayPartLogging.PAYMENT_AMOUNT and BSCI_PayPartLogging.ACH_ACCOUNT_NUMBER = '" + entityCode + "'";

                ////select @numfound = count(ID) FROM BSCI_PayPartLogging where BSCI_PayPartLogging.ID = @ID AND BSCI_PayPartLogging.PAYMENT_AMOUNT = @totalfeebalance AND BSCI_PayPartLogging.IS_SUCCESS = 1 and 
                ////BSCI_PayPartLogging.WHEN_PAYMENT_MADE < (dateadd(dd,2,getdate())) and BSCI_PayPartLogging.ID  in (select ID from custom1 where custom1.ID = @ID AND ALLOW_SITE_PAYMENT = 0)

                System.Data.DataTable allData = new System.Data.DataTable();
                using (Asi.Data.DataServer server = new Asi.Data.DataServer())
                {
                    System.Data.DataSet ds = server.ExecuteDataSet(System.Data.CommandType.Text, sql);

                    if (allData != null)
                    {
                        allData = ds.Tables[0];
                    }
                }

                if (allData != null)
                { 
                // make sure we have only 1 record...
                if (allData.Rows.Count == 1)
                {
                    int _numFound = 0;

                    foreach (System.Data.DataRow dRow in allData.Rows)
                    {
                        _numFound = (int)dRow[0];
                    }

                    if (_numFound > 0)
                    {
                        // have a pending payment, batch NOT posted...
                        return true;
                    }


                }

                }
             



                return false;

            }
            catch (Exception _Ex)
            {
                string _msgBody = "BSCI Payment iPart Error (CheckPaymentLogging): ";

                if (_Ex.Message != null)
                    _msgBody += "Error Message: " + _Ex.Message.ToString();

                if (_Ex.InnerException != null)
                    _msgBody += "; Error Inner Exception: " + _Ex.InnerException.ToString();

                if (_Ex.Source != null)
                    _msgBody += "; Error Source: " + _Ex.Source.ToString();

                _msgBody += "; ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; ";

                Logger.WriteLine(9, _msgBody, true);

                Logger.WriteLine(9, sql, true);
                
                _BSCIPartUtils.SendErrorEmail(_msgBody);

                //Response.Redirect("regsiteerror.aspx?errhandletype=1", false);

                return false;
            }
            finally
            {
            }



        }

 

        /// <summary>
        /// Simple Method to Display DEBUG Message
        /// </summary>
        /// <param name="text"></param>
            private void DebugAdd(string text)
            {
                //debug.Text = debug.Text + text + "<br>";
            }
           

          protected void CardType_DropDownList_OnLoad(object sender, EventArgs e)
          {
              if (!IsPostBack)
              {
                  foreach (var account in
                      iboAdmin.ReferenceData.CashAccounts.Where(
                      account => account.CashAccountCode.Substring(0, 2) == "W_"))
                  {
                      CardType_DropDownList.Items.Add(
                          new ListItem(account.Description, account.CashAccountCode));
                  }
              }
          }

          public void CreateCheckBoxes(int i, String chkName, String chkText, String chkAmount, Boolean blnDuesProduct)
          {   
              
                  System.Web.UI.WebControls.CheckBox checkBox = new System.Web.UI.WebControls.CheckBox();            
                  checkBox.ID = "ckb_" + chkName;

                  checkBox.Text = chkText + "&nbsp&nbsp&nbsp $" + System.Convert.ToDecimal(chkAmount).ToString("0.00") + "</BR>";
                  checkBox.Visible = true;
                  if (blnDuesProduct == true)
                      {
                          checkBox.Checked = true;
                          checkBox.Enabled = false;
                          checkBox.ForeColor = System.Drawing.Color.Red;
                         // checkBox.Visible = false;
                          if (Amount.Text.ToString() == "")
                          {
                              Amount.Text = System.Convert.ToDecimal(chkAmount).ToString("0.00");
                          }
                          else
                          {
                              Amount.Text = (System.Convert.ToDecimal(Amount.Text.ToString()) + System.Convert.ToDecimal(chkAmount)).ToString("0.00");
                          }
                         }
                      else 
                      {
                          checkBox.ForeColor = System.Drawing.Color.DeepSkyBlue;
                          checkBox.Checked = false;
                          checkBox.CheckedChanged += new EventHandler(this.chkSelected_CheckedChanged);
                          //checkBox.Visible = false;
                      }
                      checkBox.ToolTip = System.Convert.ToDecimal(chkAmount).ToString("0.00");
                      //checkBox.ToolTip = i.ToString();
                      
                     checkBox.AutoPostBack = true;            
                      
                      //this.Controls.Add(checkBox);                      
                      _checkBoxes.Add(checkBox);
                     ph_feeoptions.Controls.Add(checkBox);
                  
              }

          public void RemoveCheckBoxes()
          {
              foreach (CheckBox mCheckBox in _checkBoxes)
              {

                  this.Controls.Remove(mCheckBox);
                  //_checkBoxes.Remove(mCheckBox);
              }



          }

  
          public String duesBuilder(String _ProductCode, String _Entity)
             {
      
          decimal total = 0;

          Amount.Text = "0";

          // Create a CWebUser object. To process dues, you can’t use any other type of IiMISUser (such as CStaffUser or CContactUser), even though the 
          // function which actually processes the dues (CSubscription.PayDues) just requires an IiMISUser in its signature. If you pass anything other than a CWebUser to that function, you’ll get an error.
          CWebUser _WebUser = CWebUser.LoginByPrincipal(Asi.AppContext.CurrentPrincipal);

         // Asi.iBO.IiMISUser _iMISUser = _WebUser;
         // Asi.iBO.IiMISUser _iMISUser = Asi.iBO.ContactManagement.CContactUser.LoginByWebLogin(Asi.Security.AppPrincipal.CurrentIdentity.LoginName);

          // set-up iBO..
          _iMISUser.ThrowExceptionOnError = true;
          _iMISUser.ThrowExceptionOnWarning = false;
          Asi.iBO.ContactManagement.CContact _CContact = new Asi.iBO.ContactManagement.CContact(_iMISUser, clsSessionHandler.iMIS_LoggedIn_UserID);

          txtEmailAddress.Text = _CContact.EmailAddress.ToString();
          FirstName.Text = _CContact.FirstName.ToString();
          LastName.Text = _CContact.LastName.ToString();
         
          string ss = _CContact.PreferredBillAddress.Address1.ToString();
          string StateText = _CContact.PreferredBillAddress.StateProvince.ToString();
          string CityText = _CContact.PreferredBillAddress.City.ToString();
          string ZipText = _CContact.PreferredBillAddress.PostalCode.ToString();
          string CountryText = _CContact.PreferredBillAddress.Country.ToString();
          Address1Txt.Text = ss;
          Country.Text = CountryText;
          Zip.Text = ZipText;
          City.Text = CityText;
          State.Text = StateText;
          lblAddress1Txt.Text = "Address";
          lblCountry.Text = "Country";
          lblZip.Text = "Zip";
          lblCity.Text = "City";
          lblState.Text = "State";
          lblCCCardNumber.Text = "Card Number";
          lblFirstName.Text = "First Name";
          lblLastName.Text = "Last Name";
          iMISIDText.ReadOnly = true;
          iMISIDText.Visible = false;
          FirstName.ReadOnly = false;
          LastName.ReadOnly = false;
          Entity.ReadOnly = true;
          Amount.ReadOnly = true;

          clsSessionHandler.SHrunningDuesBalance = 0;
         
          decimal runningDuesBalance = 0;
          decimal runningVolTotalBalance = 0;
          decimal runningDuesTotalPaid = 0;
          decimal runningVolTotalPaid = 0;
          decimal runningDuesVolTotalOwed = 0;
          decimal runningDuesBilled = 0;

          Boolean blnDuesProductPaid = false;
          Boolean blnVolProductPaid = false;


            // 1st loop through fee products to clean up stuff - minor hygiene...
          foreach (CSubscription subscription2 in _CContact.Subscriptions)
          {
              // clean-up stuff... 
              if (subscription2.Copies == 0)
                  subscription2.StatusCode = "I";
              //ditto...
              subscription2.BilledContactId = clsSessionHandler.iMIS_LoggedIn_UserID;
          }
        
          bool blnCheckiBOData = _CContact.Validate();
          if (blnCheckiBOData)
              _CContact.Save();
          else
          {
              Asi.iBO.Errors.CErrors ASIErrColl = _CContact.Errors;
              string strErrorDesc = "An iBO error has occurred in the duesBuilder method for ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; The error is: ";
              if (ASIErrColl.ErrorCount > 0)
              {
                  strErrorDesc = strErrorDesc + ASIErrColl.PrimaryErrorMessage.ToString();
                  //string iii = ASIErrColl.GetError(0).Message.ToString();
              }

              Logger.WriteLine(9, strErrorDesc, true);              
              _BSCIPartUtils.SendErrorEmail(strErrorDesc);
          }



          // 2nd loop through fee products to know what checkboxes to create ...
          int i = 0;
              foreach (CSubscription subscription1 in _CContact.Subscriptions)
              {                  
                i = i + 1;
                total += subscription1.Balance;
               
                try
                {
                    if ((subscription1.DuesProduct.FinancialEntityCode == _ProductCode) && (subscription1.Balance > 0) && (subscription1.StatusCode == "A"))
                    {
                        runningDuesVolTotalOwed = runningDuesVolTotalOwed + subscription1.Balance;
                       
                        if (subscription1.ProductTypeCode == "DUES" && subscription1.DuesProduct.FinancialEntityCode == _ProductCode)
                        {                                                      
                            if ((subscription1.AmountBilled > 0) && (subscription1.CopiesPaid == 0))
                            {
                                runningDuesBalance = runningDuesBalance + subscription1.Balance;
                                runningDuesTotalPaid = runningDuesTotalPaid + subscription1.AmountPaid;

                                runningDuesBilled = runningDuesBilled + subscription1.AmountBilled;
                                CreateCheckBoxes(i, subscription1.ProductCode.ToString(), subscription1.DuesProduct.Title.ToString(), subscription1.AmountBilled.ToString(), true);
                            }
                        }

                        
                        if ((subscription1.ProductTypeCode == "VOL") && (subscription1.AmountBilled > 0) && (subscription1.CopiesPaid == 0))
                        {
                            runningVolTotalBalance = runningVolTotalBalance + subscription1.Balance;
                            runningVolTotalPaid = runningVolTotalPaid + subscription1.AmountPaid;                           

                            CreateCheckBoxes(i, subscription1.ProductCode.ToString(), subscription1.DuesProduct.Title.ToString(), subscription1.AmountBilled.ToString(), false);
                        }                        

                    }


                }
                catch (Exception _Ex)
                {
                    string _msgBody = "BSCI Payment iPart Error (duesBuilder): ";

                    if (_Ex.Message != null)
                        _msgBody += "Error Message: " + _Ex.Message.ToString();

                    if (_Ex.InnerException != null)
                        _msgBody += "; Error Inner Exception: " + _Ex.InnerException.ToString();

                    if (_Ex.Source != null)
                        _msgBody += "; Error Source: " + _Ex.Source.ToString();

                    _msgBody += "; ID: " + clsSessionHandler.iMIS_LoggedIn_UserID + "; ";

                    Logger.WriteLine(9, _msgBody, true);
                    _BSCIPartUtils.SendErrorEmail(_msgBody);

                    // show error to user..
                    asilbl_ErrorMsg.Text = _msgBody;
                    asilbl_ErrorMsg.Visible = true;                    
                }
                finally
                {
                }
            
              }   //end of for loop...



              // used to prevent duplicate payment ..
              clsSessionHandler.SHrunningDuesBalance = runningDuesBalance;
             
              // this adjusts the subscription record...
              //_CContact.Save();


              //if (runningDuesTotalPaid >= runningDuesVolTotalOwed && runningDuesTotalPaid > 0 || _checkBoxes.Count == 0 && runningDuesTotalPaid > 0)
              if (_checkBoxes.Count == 0 && blnDuesProductPaid == true || _checkBoxes.Count == 0 && blnVolProductPaid == true)
              {                  
                  iMISIDText.Text = txtDuesAlreadyPaid;
                  clsSessionHandler.TotalFeesFound = 0;
                  return "0";
              }

              else if (_checkBoxes.Count == 0 && blnDuesProductPaid == false || _checkBoxes.Count == 0 && blnVolProductPaid == false)
              {
                  clsSessionHandler.TotalFeesFound = 0;
                  return ""; //Amount.Text;
              }


              else if (_checkBoxes.Count > 0 && blnDuesProductPaid == true || _checkBoxes.Count > 0 && blnVolProductPaid == true)
              {
                 iMISIDText.Text = txtDuesAlreadyPaid;
                 clsSessionHandler.TotalFeesFound = runningDuesVolTotalOwed;
                 return runningDuesVolTotalOwed.ToString(); 
              }

              else if (_checkBoxes.Count > 0 && blnDuesProductPaid == false || _checkBoxes.Count > 0 && blnVolProductPaid == false)
              {
                  iMISIDText.Text = _Entity;
                  iMISIDText.ForeColor = System.Drawing.Color.Blue;
                  clsSessionHandler.TotalFeesFound = runningDuesVolTotalOwed;
                  return runningDuesVolTotalOwed.ToString();
              }
                                           
              else if (runningDuesBilled == 0 )
              {
                  clsSessionHandler.TotalFeesFound = 0;
                  return ""; //Amount.Text;
              }
              clsSessionHandler.TotalFeesFound = 0;
              return ""; //Amount.Text;
                      

            }
       




          protected void chkSelected_CheckedChanged(object sender, System.EventArgs e)
          {
              CheckBox checkbox = sender as CheckBox;
              if (checkbox.Checked)
              {
                  //This removes error when dues chek box is checked.
                  if (Amount.Text.ToString() == "")
                  {
                      Amount.Text = checkbox.ToolTip.ToString();

                  }
                  else if (Amount.Text.ToString() != "")
                  {
                      Amount.Text = System.Convert.ToString(System.Convert.ToDecimal(Amount.Text.ToString()) + System.Convert.ToDecimal(checkbox.ToolTip.ToString()));

                  }
              }
              if (!checkbox.Checked)
              {
                  if (Amount.Text.ToString() == "")
                  {
                      Amount.Text = "0.00";

                  }
                  else if (Amount.Text.ToString() != "")
                  {
                      Amount.Text = System.Convert.ToString(System.Convert.ToDecimal(Amount.Text.ToString()) - System.Convert.ToDecimal(checkbox.ToolTip.ToString()));
                  }
              }

              CCCardNumber.Focus();

          }

   


          /// <summary>
          /// Sends email about error from iPart .. exception type argument is string, derived from System.Exception...
          /// </summary>
          public void SendConfirmationEmail(string _Msg)
          {     
              string ServerVariables = HttpContext.Current.Request.ServerVariables.ToString();

              //Asi.Web.UI.IUserControl ctrl = (Asi.Web.UI.IUserControl)page;
              //string hh = ctrl.SubjectName;

              SmtpClient smtpClient = new SmtpClient();
              System.Net.Mail.MailMessage msg = new System.Net.Mail.MailMessage();

              // mail server config..
              // smtpClient.Host = ____Globals.SMTP_SERVER;
              // int int_PortNum = Convert.ToInt32(____Globals.SMTP_SERVER_PORT);
              // smtpClient.Port = int_PortNum;

              MailAddress fromAddress = new MailAddress(clsSessionHandler.iPartProperty_ReceiptFromEmailAddress);
              msg.From = fromAddress;

              //// process email addresses from web.config
              //System.Configuration.AppSettingsReader configurationAppSettings = new System.Configuration.AppSettingsReader();
              //string _TOs = "";
              //string _CCs = "";

              //_TOs = configurationAppSettings.GetValue("ERROREMAIL_TO", typeof(string)).ToString();
              //_CCs = configurationAppSettings.GetValue("ERROREMAIL_CC", typeof(string)).ToString();

              //string[] workthroughTOs = _TOs.Split(',');
              //foreach (string add in workthroughTOs)
              //{
              //    msg.To.Add(add);
              //}


              //string[] workthroughCCs = _CCs.Split(',');
              //foreach (string addcc in workthroughCCs)
              //{
              //    msg.To.Add(addcc);
              //}
              ////
             
              msg.To.Add(txtEmailAddress.Text);
              msg.CC.Add(clsSessionHandler.iPartProperty_ReceiptCCEmailAddress);
              msg.IsBodyHtml = true;

              msg.Subject = Entity.Text + " Dues Payment Confirmation";

             msg.Body = _Msg;

              try
              {
                  smtpClient.Send(msg);
              }
              catch (Exception _Ex)
              {
                  string _ErrorMsgBody = " BSCI PayPart Error (SendConfirmationEmail): ";

                  if (_Ex.Message != null)
                      _ErrorMsgBody += "Error Message: " + _Ex.Message.ToString();

                  if (_Ex.InnerException != null)
                      _ErrorMsgBody += "; Error Inner Exception: " + _Ex.InnerException.ToString();

                  if (_Ex.Source != null)
                      _ErrorMsgBody += "; Error Source: " + _Ex.Source.ToString();

                  Logger.WriteLine(9, "ID " + clsSessionHandler.iMIS_LoggedIn_UserID + _ErrorMsgBody, true);
                  _BSCIPartUtils.SendErrorEmail("ID " + clsSessionHandler.iMIS_LoggedIn_UserID + _ErrorMsgBody);
              }
              finally
              {
              }
          }









          /// <summary>
          /// •Basecamp: +15 years (2025)
          /// •Amazon: +20 years (2030)
          /// •Paypal: +19 years (2029)
          /// </summary>
          /// <param name="sender"></param>
          /// <param name="e"></param>
          protected void ddlYearFill()
          {
              if (!IsPostBack)
              {
                  int startY = System.DateTime.Now.Year;
                  while (startY <= System.DateTime.Now.AddYears(20).Year)
                  {
                      ddlYear.Items.Add(
                          new ListItem(startY.ToString(), startY.ToString()));
                      startY++;
                  }
                  ddlYear.Text = System.DateTime.Now.Year.ToString();
              }
          }





        #endregion





        #region Static Methods

        #endregion







    }
}